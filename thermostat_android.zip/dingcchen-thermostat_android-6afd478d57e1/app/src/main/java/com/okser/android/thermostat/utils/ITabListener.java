package com.okser.android.thermostat.utils;

public interface ITabListener {
    boolean doBackAction();

    void doSave();
}
