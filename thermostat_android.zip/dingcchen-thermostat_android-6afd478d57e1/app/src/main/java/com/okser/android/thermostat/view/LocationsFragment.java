package com.okser.android.thermostat.view;

import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.okser.android.thermostat.R;
import com.okser.android.thermostat.adapter.LocationAdapter;
import com.okser.android.thermostat.db.SnappyDBService;
import com.okser.android.thermostat.model.Location;

public class LocationsFragment extends Fragment implements View.OnClickListener {
    private ListView mListView;
    private LocationAdapter mLocationAdapter;
    private PopupWindow mPopupWindow;
    private ImageButton mRightBtn;

    private void showPopup(int pos) {
        hidePopup();
        View view = View.inflate(getActivity(), R.layout.popup, null);
        mPopupWindow = new PopupWindow(view, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
        mPopupWindow.setFocusable(true);
        mPopupWindow.setOutsideTouchable(true);
        mPopupWindow.setBackgroundDrawable(new BitmapDrawable());
        mPopupWindow.setTouchInterceptor(new View.OnTouchListener() {
            @Override
            public boolean onTouch(final View v, final MotionEvent event) {
                mPopupWindow.dismiss();
                return true;
            }
        });
        mPopupWindow.showAtLocation(mListView, Gravity.CENTER, 0, 0);
        View icon1 = view.findViewById(R.id.icon1);
        View icon2 = view.findViewById(R.id.icon2);
        View icon3 = view.findViewById(R.id.icon3);
        View icon4 = view.findViewById(R.id.icon4);
        icon1.setTag(pos);
        icon2.setTag(pos);
        icon3.setTag(pos);
        icon4.setTag(pos);
        icon1.setOnClickListener(this);
        icon2.setOnClickListener(this);
        icon3.setOnClickListener(this);
        icon4.setOnClickListener(this);
    }

    private void hidePopup() {
        if (mPopupWindow != null) {
            mPopupWindow.dismiss();
            mPopupWindow = null;
        }
    }

    @Override
    public void onClick(final View v) {
        if (v.getId() == R.id.btnright) {
            if (mLocationAdapter.isEdited()) {
                mLocationAdapter.save(getActivity());
                mRightBtn.setImageResource(R.drawable.icon_add);
            } else {
                SnappyDBService.getInstance(getActivity()).addLocation(new Location());
                mLocationAdapter.notifyDataSetChanged();
            }
        } else if (v.getId() == R.id.righttext) {
            Integer tag = (Integer) v.getTag();
            Location data = mLocationAdapter.getItem(tag);
            ((MainActivity) getActivity()).switchPage(ThermostatListFragment.newInstance(data.getName(), tag), true);
        } else if (v.getId() == R.id.icon) {
            //showPopup((Integer) v.getTag());
        } else if (v.getId() == R.id.icon1) {
            Location location = mLocationAdapter.getItem((Integer) v.getTag());
            location.setIconId(android.R.drawable.ic_dialog_alert);
            SnappyDBService.getInstance(getActivity()).updateLocation();
            hidePopup();
            mLocationAdapter.notifyDataSetChanged();
        } else if (v.getId() == R.id.icon2) {
            Location location = mLocationAdapter.getItem((Integer) v.getTag());
            location.setIconId(android.R.drawable.ic_dialog_email);
            SnappyDBService.getInstance(getActivity()).updateLocation();
            hidePopup();
            mLocationAdapter.notifyDataSetChanged();
        } else if (v.getId() == R.id.icon3) {
            Location location = mLocationAdapter.getItem((Integer) v.getTag());
            location.setIconId(android.R.drawable.ic_dialog_map);
            SnappyDBService.getInstance(getActivity()).updateLocation();
            hidePopup();
            mLocationAdapter.notifyDataSetChanged();
        } else if (v.getId() == R.id.icon4) {
            Location location = mLocationAdapter.getItem((Integer) v.getTag());
            location.setIconId(android.R.drawable.ic_dialog_info);
            SnappyDBService.getInstance(getActivity()).updateLocation();
            hidePopup();
            mLocationAdapter.notifyDataSetChanged();
        } else if (v.getId() == R.id.lefttext) {
            if (mLocationAdapter.isEdited()) {
                mRightBtn.setImageResource(R.drawable.icon_ok);
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_listview, container, false);
        mListView = (ListView) view.findViewById(R.id.listview);
        mLocationAdapter = new LocationAdapter(SnappyDBService.getInstance(getActivity()).getLocationList(), this);
        mListView.setAdapter(mLocationAdapter);
        TextView title = (TextView) view.findViewById(R.id.title);
        title.setText(R.string.title_locations);
        View titleLeft = view.findViewById(R.id.btnleft);
        titleLeft.setVisibility(View.GONE);
        mRightBtn = (ImageButton) view.findViewById(R.id.btnright);
        mRightBtn.setImageResource(R.drawable.icon_add);
        mRightBtn.setOnClickListener(this);
        return view;
    }

    @Override
    public void onViewCreated(final View view, final Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mListView.requestFocus();
    }
}
