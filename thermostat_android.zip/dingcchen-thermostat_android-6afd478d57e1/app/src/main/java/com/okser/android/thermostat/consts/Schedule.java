package com.okser.android.thermostat.consts;

public enum Schedule {
    workday, oneday, all
}
