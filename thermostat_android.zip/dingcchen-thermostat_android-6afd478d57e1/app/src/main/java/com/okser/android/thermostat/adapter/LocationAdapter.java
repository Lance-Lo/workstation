package com.okser.android.thermostat.adapter;

import android.content.Context;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.okser.android.thermostat.R;
import com.okser.android.thermostat.db.SnappyDBService;
import com.okser.android.thermostat.model.Location;
import com.okser.android.thermostat.utils.Utils;

import java.util.List;

public class LocationAdapter extends BaseAdapter implements View.OnFocusChangeListener {
    private final View.OnClickListener mClickListener;
    private final List<Location> mData;
    private boolean mEdited;

    public LocationAdapter(final List<Location> locationList, final View.OnClickListener clickListener) {
        mData = locationList;
        mClickListener = clickListener;
        mEdited = false;
    }

    @Override
    public int getCount() {
        if (mData != null) {
            return mData.size();
        }
        return 0;
    }

    @Override
    public Location getItem(final int position) {
        if (mData != null) {
            return mData.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(final int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(parent.getContext(), R.layout.item_location, null);
        }
        final EditText main = (EditText) convertView.findViewById(R.id.lefttext);
        final TextView sub = (TextView) convertView.findViewById(R.id.righttext);
        final ImageView icon = (ImageView) convertView.findViewById(R.id.icon);
        final Location data = getItem(position);
        sub.setText(String.valueOf(data.getCount()));
        if (data != null) {
            if (TextUtils.isEmpty(data.getName())) {
                main.setText(parent.getContext().getString(R.string.default_location));
            } else {
                main.setText(data.getName());
            }
        }
        main.setEnabled(true);
        main.setTag(position);
        main.setOnFocusChangeListener(this);
        main.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(final CharSequence s, final int start, final int count, final int after) {

            }

            @Override
            public void onTextChanged(final CharSequence s, final int start, final int before, final int count) {

            }

            @Override
            public void afterTextChanged(final Editable s) {
                final String afteredit = s.toString();
                if (!TextUtils.isEmpty(afteredit)) {
                    if (!afteredit.equals(data.getName())) {
                        data.setName(afteredit);
                        mEdited = true;
                        mClickListener.onClick(main);
                    }
                }
            }
        });
        icon.setImageResource(data.getIconId());
        icon.setTag(position);
        icon.setOnClickListener(mClickListener);
        sub.setTag(position);
        sub.setOnClickListener(mClickListener);
        sub.setText(String.valueOf(data.getCount()));
        return convertView;
    }

    public boolean isEdited() {
        return mEdited;
    }

    @Override
    public void onFocusChange(final View v, final boolean hasFocus) {
        if (hasFocus) {
            Utils.showKeyboard(v.getContext(), v);
        } else {
            Utils.hideKeyboard(v.getContext(), v);
        }
    }

    public void save(Context ctx) {
        SnappyDBService.getInstance(ctx).updateLocation();
        mEdited = false;
    }
}
