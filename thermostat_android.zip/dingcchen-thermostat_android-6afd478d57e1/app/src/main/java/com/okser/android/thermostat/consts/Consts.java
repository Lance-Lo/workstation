package com.okser.android.thermostat.consts;

public class Consts {
    public static final String CMD_SCH = "__SL_P_SCH";
    public static final String CMD_TEC = "__SL_P_TEC";
    public static final String KEY_API_CFG = "http://%s/thermostat_cfg.js";
    public static final String KEY_API_STATUS = "http://%s/thermostat_status.js";
    public static final String KEY_API_UPDATE = "http://%s/No_content";
    public static final String KEY_FAN = "__SL_P_FST";
    public static final String KEY_HOLDFOR = "__SL_P_HOS";
    public static final String KEY_ID = "id";
    public static final String KEY_MODE = "__SL_P_OPE";
    public static final String KEY_NAME = "name";
    public static final String KEY_PERMANENT_COOL = "__SL_P_PTH";
    public static final String KEY_PERMANENT_HEAT = "__SL_P_PTL";
    public static final String KEY_SCHEDULE_1 = "__SL_P_SC1";
    public static final String KEY_SCHEDULE_2 = "__SL_P_SC2";
    public static final String KEY_SCHEDULE_SET = "__SL_P_PGO";
    public static final String KEY_STATUS_FAN = "__SL_P_FAN";
    public static final String KEY_STATUS_HUMIDITY = "__SL_P_C_H";
    public static final String KEY_STATUS_SYSTEM = "__SL_P_SST";
    public static final String KEY_STATUS_TEMPERATURE = "__SL_P_C_T";
    public static final String KEY_SYSTEM = "__SL_P_SST";
    public static final String KEY_TEMPERATURE_UNIT = "__SL_P_TPT";
    public static final String KEY_TEMPORAY_COOL = "__SL_P_TTH";
    public static final String KEY_TEMPORAY_HEAT = "__SL_P_TTL";
    public static final String SP = " ";
    public static final int TEMP_MAX = 90;
    public static final int TEMP_MIN = 40;
    public static final String VALUE_SCH = "SCH";
    public static final String VALUE_TEC = "TEC";


}
