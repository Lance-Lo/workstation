package com.okser.android.thermostat.view;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import com.okser.android.thermostat.R;
import com.okser.android.thermostat.consts.Consts;
import com.okser.android.thermostat.consts.SmartConfigConstants;
import com.okser.android.thermostat.db.SnappyDBService;
import com.okser.android.thermostat.model.Device;
import com.okser.android.thermostat.model.Location;
import com.okser.android.thermostat.utils.MDnsCallbackInterface;
import com.okser.android.thermostat.utils.MDnsTask;
import com.okser.android.thermostat.utils.NetworkUtil;

import java.util.List;

public class NewThermostatFragment extends Fragment implements MDnsCallbackInterface, View.OnClickListener {
    private TextView mBtnSearch;
    private AlertDialog mDeviceFondDialog;
    private List<Device> mDevices;
    private MDnsTask mDnsTask;
    private TextView mEditWifiName;
    private EditText mEditWifiPassword;
    private BroadcastReceiver mReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (SmartConfigConstants.NETWORK_CHANGE_BROADCAST_ACTION.equals(action)) {
                mEditWifiName.setText(NetworkUtil.getWifiName(getActivity()));
                int networkState = NetworkUtil.getConnectionStatus(context);
                if (networkState != NetworkUtil.WIFI) {
                    if (mDnsTask != null) {
                        stopScanDevice();
                    }
                }
            }

        }
    };
    private AlertDialog mWifiDialog;

    public static NewThermostatFragment newInstance(int pos) {
        Bundle args = new Bundle();
        args.putInt(Consts.KEY_ID, pos);
        NewThermostatFragment f = new NewThermostatFragment();
        f.setArguments(args);
        return f;
    }

    private void activateWifi() {
        WifiManager wifiManager = (WifiManager) getActivity().getSystemService(Context.WIFI_SERVICE);
        if (!wifiManager.isWifiEnabled())
            wifiManager.setWifiEnabled(true);
        startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add, container, false);
        TextView title = (TextView) view.findViewById(R.id.title);
        title.setText(R.string.title_thermostat_add);
        View right = view.findViewById(R.id.btnright);
        right.setVisibility(View.GONE);
        View left = view.findViewById(R.id.btnleft);
        left.setOnClickListener(this);
        Bundle args = getArguments();
        if (args != null) {
            int pos = args.getInt(Consts.KEY_ID);
            Location location = SnappyDBService.getInstance(getActivity()).getLocation(pos);
            mDevices = location.getDevices();
        }
        IntentFilter filter = new IntentFilter();
        filter.addAction(SmartConfigConstants.NETWORK_CHANGE_BROADCAST_ACTION);
        LocalBroadcastManager.getInstance(getActivity()).registerReceiver(mReceiver, filter);
        mEditWifiName = ((EditText) view.findViewById(R.id.editwifi));
        mEditWifiPassword = ((EditText) view.findViewById(R.id.editpwd));
        mBtnSearch = ((TextView) view.findViewById(R.id.btnsearch));
        mBtnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mDnsTask != null) {
                    stopScanDevice();
                } else {
                    smartconfig_start();
                }
            }
        });
        mEditWifiName.setText(NetworkUtil.getWifiName(getActivity()));
        mEditWifiName.setEnabled(false);
        return view;
    }

    private synchronized void stopScanDevice() {
        if (mDnsTask != null) {
            mBtnSearch.setEnabled(false);
            mBtnSearch.setText(R.string.smartconfig_start);
            mDnsTask.stopScan();
            mDnsTask = null;
        }
    }

    private void smartconfig_start() {
        int networkState = NetworkUtil.getConnectionStatus(getActivity());
        if (networkState != NetworkUtil.WIFI) {
            showWifiDialog(getActivity());
        } else {
            final String wifiname = mEditWifiName.getText().toString().trim();
            final String password = mEditWifiPassword.getText().toString().trim();
            final String gateway = NetworkUtil.getGateway(getActivity());
            if (TextUtils.isEmpty(wifiname)) {
                mEditWifiName.setError(getString(R.string.emptyedit));
                return;
            }
            if (TextUtils.isEmpty(password)) {
                mEditWifiPassword.setError(getString(R.string.emptyedit));
                return;
            }
            if (TextUtils.isEmpty(gateway)) {
                Log.e(this.getClass().getSimpleName(), "gateway is null");
                return;
            }
            startScanDevice(wifiname, password, gateway);
        }
    }

    public void showWifiDialog(final Context context) {
        Activity act = getActivity();
        if (act != null) {
            act.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle(R.string.dialog_nowifi_title);
                    builder.setMessage(R.string.dialog_nowifi_desp);
                    builder.setPositiveButton(R.string.btn_ok, null);
                    builder.setCancelable(false);
                    mWifiDialog = builder.create();
                    mWifiDialog.show();
                }
            });
        }
    }

    private synchronized void startScanDevice(final String name, final String password, final String gateway) {
        if (mDnsTask == null) {
            mBtnSearch.setEnabled(false);
            mBtnSearch.setText(R.string.smartconfig_cancelsearch);
            mDnsTask = new MDnsTask(getActivity(), this, name, password, gateway);
        }
    }

    @Override
    public void onDestroyView() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Activity.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(mEditWifiName.getWindowToken(), 0);
        LocalBroadcastManager.getInstance(getActivity()).unregisterReceiver(mReceiver);
        stopScanDevice();
        super.onDestroyView();
    }

    @Override
    public void onDeviceStoped(final List<Device> list) {
        boolean newFound = false;
        if (list != null) {
            for (Device newDevice : list) {
                newDevice.setName(getString(R.string.default_devicename));
                boolean skip = false;
                for (Device i : mDevices) {
                    if (i.getPrivateName().equals(newDevice.getPrivateName())) {
                        skip = true;
                        break;
                    }
                }
                if (!skip) {
                    newFound = true;
                    mDevices.add(newDevice);
                }
            }
        }
        if (newFound) {
            SnappyDBService.getInstance(getActivity()).updateLocation();
            showDeviceFoundDialog();
        } else {
            showDeviceNotFoundDialog();
        }
        Log.i(this.getClass().getSimpleName(), "onDeviceStoped");
        Activity act = getActivity();
        if (act != null) {
            act.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    mDnsTask = null;
                    mBtnSearch.setText(R.string.smartconfig_start);
                    mBtnSearch.setEnabled(true);
                }
            });
        }
    }

    private void showDeviceFoundDialog() {
        Activity act = getActivity();
        if (act != null) {
            act.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle(R.string.dialog_success);
                    builder.setMessage(R.string.dialog_devicefound_desp);
                    builder.setPositiveButton(R.string.btn_ok, new OnClickListener() {
                        @Override
                        public void onClick(final DialogInterface dialog, final int which) {
                            getFragmentManager().popBackStack();
                        }
                    });
                    mDeviceFondDialog = builder.create();
                    mDeviceFondDialog.show();
                }
            });
        }
    }

    private void showDeviceNotFoundDialog() {
        Activity act = getActivity();
        if (act != null) {
            act.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setTitle(R.string.dialog_devicenotfound_title);
                    builder.setMessage(R.string.dialog_devicenotfound_desp);
                    builder.setPositiveButton(R.string.btn_ok, new OnClickListener() {
                        @Override
                        public void onClick(final DialogInterface dialog, final int which) {
                            getFragmentManager().popBackStack();
                        }
                    });
                    mDeviceFondDialog = builder.create();
                    mDeviceFondDialog.show();
                }
            });
        }
    }

    @Override
    public void onDeviceStarted() {
        Log.i(this.getClass().getSimpleName(), "onDeviceStarted");
        Activity act = getActivity();
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mBtnSearch.setEnabled(true);
            }
        });

    }

    @Override
    public void onClick(final View v) {
        getFragmentManager().popBackStack();
    }
}