package com.okser.android.thermostat.adapter;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.okser.android.thermostat.R;
import com.okser.android.thermostat.consts.Consts;
import com.okser.android.thermostat.consts.Fan;
import com.okser.android.thermostat.consts.System;
import com.okser.android.thermostat.consts.Unit;
import com.okser.android.thermostat.db.SnappyDBService;
import com.okser.android.thermostat.model.Device;
import com.okser.android.thermostat.model.ThermostatValue;
import com.okser.android.thermostat.utils.ExStringRequest;
import com.okser.android.thermostat.utils.Utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ThermostatAdapter extends BaseAdapter implements View.OnFocusChangeListener {
    private static final int MY_SOCKET_TIMEOUT_MS = 5000;
    private final Context mCtx;
    private final List<Device> mData;
    private final View.OnClickListener mOnClickListener;
    private final RequestQueue mRequestQueue;
    private final Map<String, ThermostatValue> mValues;
    private int mCompletedCount;
    private ProgressDialog mProgressDialog;
    private AlertDialog mErrorDialog;
    private int mFailCount;

    public ThermostatAdapter(final List<Device> devices, final Context ctx, View.OnClickListener onClickListener) {
        mData = devices;
        mValues = new HashMap<>(devices.size());
        mRequestQueue = Volley.newRequestQueue(ctx);
        mOnClickListener = onClickListener;
        mCtx = ctx;
        mProgressDialog = null;
        if ((devices != null) && (devices.size() > 0)) {
            fetchAllData();
        }
    }

    private void fetchAllData() {
        mCompletedCount = 0;
        mFailCount = 0;
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
            mProgressDialog = null;
        }
        mProgressDialog = new ProgressDialog(mCtx);
        mProgressDialog.setMessage(mCtx.getString(R.string.loading));
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();
        for (Device i : mData) {
            final String host = i.getHost();
            final String apiStatus = String.format(Consts.KEY_API_STATUS, host);
            final String apiConfig = String.format(Consts.KEY_API_CFG, host);
            if (!mValues.containsKey(host)) {
                mValues.put(host, new ThermostatValue());
            }
            ExStringRequest status = new ExStringRequest(apiStatus, new Response.Listener<String>() {
                @Override
                public void onResponse(final String response) {
                    Log.i(ThermostatAdapter.class.getSimpleName(), "response:" + response + " host:" + host);
                    String[] datapair = response.split(",");
                    for (String strValue : datapair) {
                        if (TextUtils.isEmpty(strValue)) {
                            continue;
                        }
                        String[] keys = strValue.split(":");
                        if ((keys != null) && keys.length >= 2) {
                            if (TextUtils.isEmpty(keys[0]) || keys[1] == null) {
                                continue;
                            }
                            final String key = keys[0].trim();
                            final String value = (key == null ? null : keys[1].trim());
                            ThermostatValue newValue = mValues.get(host);
                            if (Consts.KEY_STATUS_HUMIDITY.equals(key)) {
                                newValue.setHumidity(TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                            }

                            if (Consts.KEY_STATUS_TEMPERATURE.equals(key)) {
                                newValue.setTemperature(TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                            }
                        }

                    }
                    checkResult();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(final VolleyError error) {
                    Log.e(ThermostatAdapter.class.getSimpleName(), "response: error" + error.getMessage(), error);
                    mFailCount++;
                    checkResult();
                    Toast.makeText(mCtx, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            });

            ExStringRequest config = new ExStringRequest(apiConfig, new Response.Listener<String>() {
                @Override
                public void onResponse(final String response) {
                    Log.i(ThermostatAdapter.class.getSimpleName(), "response:" + response + " host:" + host);
                    String[] datapair = response.split(",");
                    for (String strValue : datapair) {
                        if (TextUtils.isEmpty(strValue)) {
                            continue;
                        }
                        String[] keys = strValue.split(":");
                        if ((keys != null) && keys.length >= 2) {
                            if (TextUtils.isEmpty(keys[0]) || keys[1] == null) {
                                continue;
                            }
                            final String key = keys[0].trim();
                            final String value = (key == null ? null : keys[1].trim());
                            ThermostatValue newValue = mValues.get(host);
                            if (Consts.KEY_FAN.equals(key)) {
                                int fan = TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value);
                                if (fan == Fan.Circulate.ordinal()) {
                                    newValue.setFan(Fan.Circulate);
                                } else if (fan == Fan.On.ordinal()) {
                                    newValue.setFan(Fan.On);
                                } else {
                                    newValue.setFan(Fan.Auto);
                                }
                            }

                            if (Consts.KEY_SYSTEM.equals(key)) {
                                int sys = TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value);
                                if (sys == System.Heat.ordinal()) {
                                    newValue.setSystem(System.Heat);
                                } else if (sys == System.Cool.ordinal()) {
                                    newValue.setSystem(System.Cool);
                                } else if (sys == System.Auto.ordinal()) {
                                    newValue.setSystem(System.Auto);
                                } else {
                                    newValue.setSystem(System.Off);
                                }
                            }
                            Log.i(ThermostatAdapter.class.getSimpleName(), "newValue:" + newValue);
                        }

                    }

                    checkResult();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(final VolleyError error) {
                    Log.e(ThermostatAdapter.class.getSimpleName(), "response: error" + error.getMessage(), error);
                    mFailCount++;
                    checkResult();
                    Toast.makeText(mCtx, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            status.setRetryPolicy(new DefaultRetryPolicy(
                    MY_SOCKET_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            config.setRetryPolicy(new DefaultRetryPolicy(
                    MY_SOCKET_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            mRequestQueue.add(status);
            mRequestQueue.add(config);
        }
    }

    private void showErrorDialog() {
        if (mErrorDialog != null) {
            mErrorDialog.dismiss();
            mErrorDialog = null;
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(mCtx);
        builder.setMessage(R.string.msg_cannotfetchdata);
        builder.setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, final int which) {
                fetchAllData();
            }
        });
        builder.setNegativeButton(R.string.btn_cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, final int which) {
                notifyDataSetChanged();
            }
        });
        mErrorDialog = builder.create();
        mErrorDialog.show();
    }

    private synchronized void checkResult() {
        mCompletedCount++;
        Log.i(this.getClass().getSimpleName(), " completeCount:" + mCompletedCount + " fail:" + mFailCount);
        if (mCompletedCount >= (2 * getCount())) {
            if (mFailCount > 0) {
                showErrorDialog();
            } else {
                notifyDataSetChanged();
            }
            if (mProgressDialog != null) {
                mProgressDialog.dismiss();
                mProgressDialog = null;
            }
        }

    }

    public void destory() {
        mRequestQueue.cancelAll(new RequestQueue.RequestFilter() {
                                    @Override
                                    public boolean apply(final Request<?> request) {
                                        return true;
                                    }
                                }
        );
        mValues.clear();
        if (mProgressDialog != null) {
            mProgressDialog.dismiss();
            mProgressDialog = null;
        }
        if (mErrorDialog != null) {
            mErrorDialog.dismiss();
            mErrorDialog = null;
        }
    }

    @Override
    public int getCount() {
        if (mData != null) {
            return mData.size();
        }
        return 0;
    }

    @Override
    public Device getItem(final int position) {
        if (mData != null) {
            return mData.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(final int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        if (convertView == null) {
            convertView = View.inflate(parent.getContext(), R.layout.item_thermostat, null);
        }
        final EditText main = (EditText) convertView.findViewById(R.id.main);
        TextView temperature = (TextView) convertView.findViewById(R.id.temperature);
        TextView fan = (TextView) convertView.findViewById(R.id.label_fan);
        TextView humidity = (TextView) convertView.findViewById(R.id.label_humidity);
        TextView system = (TextView) convertView.findViewById(R.id.label_system);
        View devicepanel = convertView.findViewById(R.id.device);
        devicepanel.setOnClickListener(mOnClickListener);
        devicepanel.setTag(position);
        final Device device = getItem(position);
        if (device != null) {
            if (TextUtils.isEmpty(device.getName())) {
                main.setText(parent.getContext().getString(R.string.default_location));
            } else {
                main.setText(device.getName());
            }
            main.setTag(position);
            main.setOnFocusChangeListener(this);
        }
        final ThermostatValue value = getValue(device.getHost());
        Log.e(ThermostatAdapter.class.getSimpleName(), "getview:" + value + " host:" + device.getHost());
        if (value != null) {
            final Fan fanValue = value.getFan();
            if (fanValue == Fan.On) {
                fan.setText(R.string.fan_status_on);
            } else if (fanValue == Fan.Circulate) {
                fan.setText(R.string.fan_status_circulate);
            } else {
                fan.setText(R.string.fan_status_auto);
            }

            final System systemValue = value.getSystem();
            if (systemValue == System.Auto) {
                system.setText(R.string.system_autochangeover);
            } else if (systemValue == System.Cool) {
                system.setText(R.string.system_cool);
            } else if (systemValue == System.Heat) {
                system.setText(R.string.system_heat);
            } else {
                system.setText(R.string.system_off);
            }
            humidity.setText(value.getHumidity() + parent.getContext().getString(R.string.humidity_unit));
            Utils.setTemperature(convertView.getContext(), temperature, value.getTemperature(), Unit.F);
        } else {
            fan.setText("");
            system.setText("");
            humidity.setText("");
            Utils.setTemperature(convertView.getContext(), temperature, 0, Unit.F);
        }
        return convertView;
    }

    public ThermostatValue getValue(final String host) {
        if (mValues != null) {
            return mValues.get(host);
        }
        return null;
    }

    @Override
    public void onFocusChange(final View v, final boolean hasFocus) {
        if (hasFocus) {
            Utils.showKeyboard(v.getContext(), v);
            final Integer postion = (Integer) v.getTag();
            final Device device = getItem(postion);
            final EditText edit = (EditText) v;
            edit.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(final CharSequence s, final int start, final int count, final int after) {

                }

                @Override
                public void onTextChanged(final CharSequence s, final int start, final int before, final int count) {

                }

                @Override
                public void afterTextChanged(final Editable s) {
                    if (!TextUtils.isEmpty(s.toString())) {
                        device.setName(s.toString());
                        SnappyDBService.getInstance(mCtx).updateLocation();
                    }
                }
            });
        } else {
            Utils.hideKeyboard(v.getContext(), v);
        }
    }
}
