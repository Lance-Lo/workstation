package com.okser.android.thermostat.consts;

public enum System {
    Off, Cool, Heat, Auto
}
