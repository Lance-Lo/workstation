package com.okser.android.thermostat.view;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.widget.FrameLayout;

public class MainActivity extends FragmentActivity {

    @Override
    public void onBackPressed() {
        FragmentManager fragmentManager = this.getSupportFragmentManager();
        Fragment f = fragmentManager.findFragmentById(android.R.id.widget_frame);
        if (f instanceof ConferenceFragment) {
            if (!((ConferenceFragment) f).doBackAction()) {
                return;
            }
        }
        if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
            getSupportFragmentManager().popBackStack();
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setId(android.R.id.widget_frame);
        setContentView(frameLayout);
        switchPage(new LocationsFragment(), false);
    }

    public void switchPage(Fragment fragment, boolean add) {
        FragmentManager fragmentManager = this.getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(android.R.id.widget_frame, fragment);
        if (add) {
            transaction.addToBackStack(null);
        }
        transaction.commit();
    }
}
