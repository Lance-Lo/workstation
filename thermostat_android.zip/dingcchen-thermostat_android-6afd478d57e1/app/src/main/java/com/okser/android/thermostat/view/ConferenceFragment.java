package com.okser.android.thermostat.view;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.okser.android.thermostat.R;
import com.okser.android.thermostat.consts.Consts;
import com.okser.android.thermostat.utils.ExStringRequest;
import com.okser.android.thermostat.utils.ITabListener;
import com.okser.android.thermostat.utils.NetworkUtil;
import com.okser.android.thermostat.utils.Utils;

import java.util.HashMap;
import java.util.Map;

public class ConferenceFragment extends Fragment implements View.OnClickListener {
    private int mCurrentTab;
    private String mHost;
    private Bundle mParams;
    private int mPendingId;
    private View mProgressBar;
    private RequestQueue mRequestQueue;
    private ImageButton mRightBtn;
    private View mTab_sched;
    private View mTab_system;
    private View mTab_tstat;
    private TextView mTitleText;

    public static ConferenceFragment newInstance(String host, final String name) {
        ConferenceFragment f = new ConferenceFragment();
        Bundle args = new Bundle();
        args.putString(Consts.KEY_ID, host);
        args.putString(Consts.KEY_NAME, name);
        f.setArguments(args);
        return f;
    }

    private void showConfirmSave(final int pendingId) {
        mPendingId = pendingId;
        Utils.showSubmitConfirm(getActivity(), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(final DialogInterface dialog, final int which) {
                if (which == DialogInterface.BUTTON_POSITIVE) {
                    Fragment f = getChildFragmentManager().findFragmentById(R.id.tabcontent);
                    if (f instanceof ITabListener) {
                        ((ITabListener) f).doSave();
                    }
                } else {
                    afterSave();
                }
            }
        });
    }

    public boolean doBackAction() {
        Fragment f = getChildFragmentManager().findFragmentById(R.id.tabcontent);
        if (f instanceof ITabListener) {
            if (((ITabListener) f).doBackAction()) {
                if (mRightBtn.getVisibility() == View.VISIBLE) {
                    showConfirmSave(-1);
                    return false;
                }
                return true;
            } else {
                return false;
            }
        }
        return true;
    }

    @Override
    public void onClick(final View v) {
        if (v.getId() == R.id.btnleft) {
            if (doBackAction()) {
                getFragmentManager().popBackStack();
            }
        } else if (v.getId() == R.id.btnright) {
            Fragment f = getChildFragmentManager().findFragmentById(R.id.tabcontent);
            if (f instanceof ITabListener) {
                ((ITabListener) f).doSave();
            }
        } else if (v.getId() == R.id.progress) {
        } else {
            if (mCurrentTab != v.getId()) {
                if (mRightBtn.getVisibility() == View.VISIBLE) {
                    showConfirmSave(v.getId());
                } else {
                    switchViewById(v.getId());
                }
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_conference, container, false);
        mProgressBar = view.findViewById(R.id.progress);
        mProgressBar.setOnClickListener(this);
        mRightBtn = (ImageButton) view.findViewById(R.id.btnright);
        mRightBtn.setImageResource(R.drawable.icon_ok);
        mRightBtn.setVisibility(View.GONE);
        mRightBtn.setOnClickListener(this);
        mTitleText = (TextView) view.findViewById(R.id.title);

        View left = view.findViewById(R.id.btnleft);
        left.setOnClickListener(this);
        mTab_tstat = view.findViewById(R.id.tab_tstat);
        mTab_sched = view.findViewById(R.id.tab_setsched);
        mTab_system = view.findViewById(R.id.tab_system);
        mTab_tstat.setEnabled(false);
        mTab_sched.setEnabled(false);
        mTab_system.setEnabled(false);
        mTab_tstat.setOnClickListener(this);
        mTab_sched.setOnClickListener(this);
        mTab_system.setOnClickListener(this);
        mParams = new Bundle();
        Bundle args = getArguments();
        mCurrentTab = -1;
        if (args != null) {
            String name = args.getString(Consts.KEY_NAME);
            mTitleText.setText(name);
            mHost = args.getString(Consts.KEY_ID);
            String api = String.format(Consts.KEY_API_CFG, mHost);
            Log.i(this.getClass().getSimpleName(), "api:" + api);
            mProgressBar.setVisibility(View.VISIBLE);
            mRequestQueue = Volley.newRequestQueue(getActivity());
            ExStringRequest request = new ExStringRequest(api, new Response.Listener<String>() {
                @Override
                public void onResponse(final String response) {
                    if (NetworkUtil.showNetworkDialog(ConferenceFragment.this)) {
                        parseConfig(response);
                        switchViewById(R.id.tab_tstat);
                        mProgressBar.setVisibility(View.GONE);
                        mTab_tstat.setEnabled(true);
                        mTab_sched.setEnabled(true);
                        mTab_system.setEnabled(true);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(final VolleyError error) {
                    Log.e(this.getClass().getSimpleName(), "" + error.getMessage(), error);
                    mProgressBar.setVisibility(View.GONE);
                }
            });
            mRequestQueue.add(request);
        }
        return view;
    }

    private void switchViewById(int id) {
        mRightBtn.setVisibility(View.INVISIBLE);
        mCurrentTab = id;
        if (id == R.id.tab_setsched) {
            mTab_sched.setSelected(true);
            mTab_system.setSelected(false);
            mTab_tstat.setSelected(false);
            switchPage(SetSchedFragment.newInstance(mParams), false);
        } else if (id == R.id.tab_system) {
            mTab_sched.setSelected(false);
            mTab_system.setSelected(true);
            mTab_tstat.setSelected(false);
            switchPage(SystemFragment.newInstance(mParams), false);
        } else if (id == R.id.tab_tstat) {
            mTab_sched.setSelected(false);
            mTab_system.setSelected(false);
            mTab_tstat.setSelected(true);
            switchPage(TStatFragment.newInstance(mParams), false);
        }
    }

    public void switchPage(Fragment fragment, boolean add) {
        FragmentManager fragmentManager = this.getChildFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.tabcontent, fragment);
        if (add) {
            transaction.addToBackStack(null);
        }
        transaction.commit();
    }

    private void parseConfig(String response) {
        String[] datapair = response.split(",");
        for (String strValue : datapair) {
            if (TextUtils.isEmpty(strValue)) {
                continue;
            }
            String[] keys = strValue.split(":");
            if ((keys != null) && keys.length >= 2) {
                if (TextUtils.isEmpty(keys[0]) || keys[1] == null) {
                    continue;
                }
                final String key = keys[0].trim();
                final String value = (key == null ? null : keys[1].trim());
                if (Consts.KEY_TEMPORAY_COOL.equals(key)) {
                    mParams.putInt(Consts.KEY_TEMPORAY_COOL, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }
                if (Consts.KEY_TEMPORAY_HEAT.equals(key)) {
                    mParams.putInt(Consts.KEY_TEMPORAY_HEAT, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }

                if (Consts.KEY_PERMANENT_COOL.equals(key)) {
                    mParams.putInt(Consts.KEY_PERMANENT_COOL, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }
                if (Consts.KEY_PERMANENT_HEAT.equals(key)) {
                    mParams.putInt(Consts.KEY_PERMANENT_HEAT, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }
                if (Consts.KEY_MODE.equals(key)) {
                    mParams.putInt(Consts.KEY_MODE, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }

                if (Consts.KEY_FAN.equals(key)) {
                    mParams.putInt(Consts.KEY_FAN, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }

                if (Consts.KEY_SYSTEM.equals(key)) {
                    mParams.putInt(Consts.KEY_SYSTEM, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }

                if (Consts.KEY_SCHEDULE_SET.equals(key)) {
                    mParams.putInt(Consts.KEY_SCHEDULE_SET, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }

                if (Consts.KEY_HOLDFOR.equals(key)) {
                    mParams.putLong(Consts.KEY_HOLDFOR, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }
                if (Consts.KEY_TEMPERATURE_UNIT.equals(key)) {
                    mParams.putInt(Consts.KEY_TEMPERATURE_UNIT, TextUtils.isEmpty(value) ? 0 : Integer.parseInt(value));
                }
                if (Consts.KEY_SCHEDULE_1.equals(key)) {
                    mParams.putString(Consts.KEY_SCHEDULE_1, value);
                }
                if (Consts.KEY_SCHEDULE_2.equals(key)) {
                    mParams.putString(Consts.KEY_SCHEDULE_2, value);
                }

            }
        }
    }

    @Override
    public void onDestroyView() {
        if (mRequestQueue != null) {
            mRequestQueue.cancelAll(new RequestQueue.RequestFilter() {
                @Override
                public boolean apply(final Request<?> request) {
                    return true;
                }
            });
        }
        super.onDestroyView();
    }

    public void saveRequest(final Bundle args) {
        if (NetworkUtil.showNetworkDialog(this)) {
            mProgressBar.setVisibility(View.VISIBLE);
            mParams.clear();
            mParams.putAll(args);
            final String url = String.format(Consts.KEY_API_UPDATE, mHost);
            SaveRequest request = new SaveRequest(url, new Response.Listener<String>() {
                @Override
                public void onResponse(final String response) {
                    afterSave();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(final VolleyError error) {
                    Log.e(this.getClass().getSimpleName(), "onErrorResponse:" + error.getMessage(), error);
                    afterSave();
                }
            });
            mRequestQueue.add(request);
        }
    }

    private void afterSave() {
        mProgressBar.setVisibility(View.GONE);
        if (mPendingId == -1) {
            getFragmentManager().popBackStack();
        } else if (mPendingId != mCurrentTab) {
            switchViewById(mPendingId);
        }
        mPendingId = -2;
    }

    public void setTitle(final String value) {
        if (TextUtils.isEmpty(value)) {
            Bundle args = getArguments();
            if (args != null) {
                String name = args.getString(Consts.KEY_NAME);
                mTitleText.setText(name);
            }
        } else {
            mTitleText.setText(value);
        }
    }

    public void updateRightBtn(final boolean show) {
        mRightBtn.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    private class SaveRequest extends StringRequest {

        public SaveRequest(final String url, final Response.Listener<String> listener, final Response.ErrorListener errorListener) {
            super(Method.POST, url, listener, errorListener);
        }

        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            Map<String, String> params = super.getParams();
            if (params == null) {
                params = new HashMap<>();
            }
            params.put(Consts.KEY_SYSTEM, String.valueOf(mParams.getInt(Consts.KEY_SYSTEM)));
            params.put(Consts.KEY_FAN, String.valueOf(mParams.getInt(Consts.KEY_FAN)));
            params.put(Consts.KEY_TEMPORAY_HEAT, String.valueOf(mParams.getInt(Consts.KEY_TEMPORAY_HEAT)));
            params.put(Consts.KEY_TEMPORAY_COOL, String.valueOf(mParams.getInt(Consts.KEY_TEMPORAY_COOL)));
            params.put(Consts.KEY_PERMANENT_HEAT, String.valueOf(mParams.getInt(Consts.KEY_PERMANENT_HEAT)));
            params.put(Consts.KEY_PERMANENT_COOL, String.valueOf(mParams.getInt(Consts.KEY_PERMANENT_COOL)));
            params.put(Consts.KEY_HOLDFOR, String.valueOf(mParams.getLong(Consts.KEY_HOLDFOR)));
            params.put(Consts.KEY_MODE, String.valueOf(mParams.getInt(Consts.KEY_MODE)));
            params.put(Consts.KEY_SCHEDULE_SET, String.valueOf(mParams.getInt(Consts.KEY_SCHEDULE_SET)));
            params.put(Consts.KEY_SCHEDULE_1, mParams.getString(Consts.KEY_SCHEDULE_1));
            params.put(Consts.KEY_SCHEDULE_2, mParams.getString(Consts.KEY_SCHEDULE_2));
            params.put(Consts.CMD_TEC, Consts.VALUE_TEC);
            params.put(Consts.CMD_SCH, Consts.VALUE_SCH);
            return params;
        }

        @Override
        protected Response<String> parseNetworkResponse(NetworkResponse response) {
            Log.i(this.getClass().getSimpleName(), "response:" + response.headers + " code:" + response.statusCode);
            Response<String> st = Response.success("", HttpHeaderParser.parseCacheHeaders(response));
            return st;
        }
    }
}
