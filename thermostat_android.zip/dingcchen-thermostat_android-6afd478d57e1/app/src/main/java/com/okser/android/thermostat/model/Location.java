package com.okser.android.thermostat.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Location implements Serializable {
    private final List<Device> mData;
    private int mIconId;
    private String mName;

    public Location() {
        mData = new ArrayList<>();
        mIconId = android.R.drawable.ic_dialog_alert;
    }

    public int getCount() {
        return mData.size();
    }

    public List<Device> getDevices() {
        return mData;
    }

    public int getIconId() {
        return mIconId;
    }

    public void setIconId(final int iconId) {
        mIconId = iconId;
    }

    public String getName() {
        return mName;
    }

    public void setName(final String name) {
        mName = name;
    }
}
