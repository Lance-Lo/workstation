package com.okser.android.thermostat.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LocationList implements Serializable {
    private final List<Location> mData;

    public LocationList() {
        mData = new ArrayList<>();
    }

    public void add(final Location location) {
        mData.add(location);
    }

    public List<Location> getData() {
        return mData;
    }
}
