package com.okser.android.thermostat.view;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.okser.android.thermostat.R;
import com.okser.android.thermostat.adapter.ThermostatAdapter;
import com.okser.android.thermostat.consts.Consts;
import com.okser.android.thermostat.db.SnappyDBService;
import com.okser.android.thermostat.model.Device;
import com.okser.android.thermostat.model.Location;
import com.okser.android.thermostat.utils.NetworkUtil;

import java.util.List;

public class ThermostatListFragment extends Fragment implements View.OnClickListener {
    private ListView mListView;
    private int mPos;
    private ThermostatAdapter mThermostatAdapter;

    public static ThermostatListFragment newInstance(final String name, final int position) {
        ThermostatListFragment f = new ThermostatListFragment();
        Bundle args = new Bundle();
        args.putString(Consts.KEY_NAME, name);
        args.putInt(Consts.KEY_ID, position);
        f.setArguments(args);
        return f;
    }

    @Override
    public void onClick(final View v) {
        if (v.getId() == R.id.btnleft) {
            this.getFragmentManager().popBackStack();
        } else if (v.getId() == R.id.btnright) {
            Bundle args = getArguments();
            if (args != null) {
                ((MainActivity) getActivity()).switchPage(NewThermostatFragment.newInstance(mPos), true);
                //((MainActivity) getActivity()).switchPage(new ConferenceFragment(), true);
            }
        } else {
            v.setEnabled(false);
            if (NetworkUtil.showNetworkDialog(ThermostatListFragment.this)) {
                Integer tag = (Integer) v.getTag();
                Device device = mThermostatAdapter.getItem(tag);
                ((MainActivity) getActivity()).switchPage(ConferenceFragment.newInstance(device.getHost(), device.getName()), true);
            } else {
                v.setEnabled(true);
            }
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_listview, container, false);
        mListView = (ListView) view.findViewById(R.id.listview);
        Bundle args = getArguments();
        List<Device> list = null;

        if (args != null) {
            mPos = args.getInt(Consts.KEY_ID);
            Location location = SnappyDBService.getInstance(getActivity()).getLocation(mPos);
            list = location.getDevices();
        }
        mThermostatAdapter = new ThermostatAdapter(list, getActivity(), this);
        mListView.setAdapter(mThermostatAdapter);
        TextView title = (TextView) view.findViewById(R.id.title);
        title.setText(R.string.title_thermostats);
        View left = view.findViewById(R.id.btnleft);
        left.setOnClickListener(this);
        ImageButton right = (ImageButton) view.findViewById(R.id.btnright);
        right.setImageResource(R.drawable.icon_search);
        right.setOnClickListener(this);

        return view;
    }

    @Override
    public void onDestroyView() {
        mListView.setAdapter(null);
        if (mThermostatAdapter != null) {
            mThermostatAdapter.destory();
            mThermostatAdapter = null;
        }
        super.onDestroyView();
    }
}
