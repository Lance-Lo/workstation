package com.okser.android.thermostat.view;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

import com.okser.android.thermostat.R;
import com.okser.android.thermostat.consts.Consts;
import com.okser.android.thermostat.consts.Fan;
import com.okser.android.thermostat.consts.System;
import com.okser.android.thermostat.utils.ITabListener;

public class SystemFragment extends Fragment implements ITabListener, RadioGroup.OnCheckedChangeListener, DialogInterface.OnClickListener {
    private Fan mFan;
    private RadioGroup mFanGroup;
    private Fan mOldFan;
    private System mOldSystem;
    private System mSystem;
    private RadioGroup mSystemGroup;

    public static SystemFragment newInstance(Bundle extras) {
        Bundle args = new Bundle(extras);
        SystemFragment f = new SystemFragment();
        f.setArguments(args);
        return f;
    }

    @Override
    public boolean doBackAction() {
        return true;
    }

    public void doSave() {
        Bundle result = new Bundle(getArguments());
        result.putInt(Consts.KEY_SYSTEM, mSystem.ordinal());
        result.putInt(Consts.KEY_FAN, mFan.ordinal());
        mOldSystem = mSystem;
        mOldFan = mFan;
        ConferenceFragment f = (ConferenceFragment) getParentFragment();
        f.saveRequest(result);
        updateView();
    }

    @Override
    public void onCheckedChanged(final RadioGroup group, final int checkedId) {
        if (group.getId() == R.id.radio_systm) {
            if (checkedId == R.id.system_auto) {
                mSystem = System.Auto;
            } else if (checkedId == R.id.system_heat) {
                mSystem = System.Heat;
            } else if (checkedId == R.id.system_cool) {
                mSystem = System.Cool;
            } else {
                mSystem = System.Off;
            }
        } else if (group.getId() == R.id.radio_fan) {
            if (checkedId == R.id.fan_auto) {
                mFan = Fan.Auto;
            } else if (checkedId == R.id.fan_circulate) {
                mFan = Fan.Circulate;
            } else {
                mFan = Fan.On;
            }
        }
        updateView();
    }

    private void updateView() {
        boolean changed = ((mFan != mOldFan) || (mSystem != mOldSystem));
        Fragment f = getParentFragment();
        if (f instanceof ConferenceFragment) {
            ((ConferenceFragment) f).updateRightBtn(changed);
        }
    }

    @Override
    public void onClick(final DialogInterface dialog, final int which) {
        doSave();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab_system, container, false);
        mSystemGroup = (RadioGroup) view.findViewById(R.id.radio_systm);
        mFanGroup = (RadioGroup) view.findViewById(R.id.radio_fan);
        buildupData(view);

        bindEvent();
        return view;
    }

    private void buildupData(View view) {
        Bundle args = getArguments();
        if (args != null) {
            int fan = args.getInt(Consts.KEY_FAN);
            if (fan == Fan.On.ordinal()) {
                mOldFan = Fan.On;
            } else if (fan == Fan.Circulate.ordinal()) {
                mOldFan = Fan.Circulate;
            } else {
                mOldFan = Fan.Auto;
            }

            int sys = args.getInt(Consts.KEY_SYSTEM);
            if (sys == System.Cool.ordinal()) {
                mOldSystem = System.Cool;
            } else if (sys == System.Heat.ordinal()) {
                mOldSystem = System.Heat;
            } else if (sys == System.Auto.ordinal()) {
                mOldSystem = System.Auto;
            } else {
                mOldSystem = System.Off;
            }
        } else {
            mOldFan = Fan.Auto;
            mOldSystem = System.Off;
        }
        initData(view);
    }

    private void initData(View view) {
        mSystem = mOldSystem;
        mFan = mOldFan;
        bindView(view);
    }

    private void bindView(View view) {
        if (mSystem == System.Auto) {
            mSystemGroup.check(R.id.system_auto);
        } else if (mSystem == System.Off) {
            mSystemGroup.check(R.id.system_off);
        } else if (mSystem == System.Cool) {
            mSystemGroup.check(R.id.system_cool);
        } else {
            mSystemGroup.check(R.id.system_heat);
        }
        if (mFan == Fan.Auto) {
            mFanGroup.check(R.id.fan_auto);
        } else if (mFan == Fan.On) {
            mFanGroup.check(R.id.fan_on);
        } else if (mFan == Fan.Circulate) {
            mFanGroup.check(R.id.fan_circulate);
        }
    }

    private void bindEvent() {
        mSystemGroup.setOnCheckedChangeListener(this);
        mFanGroup.setOnCheckedChangeListener(this);
    }
}
