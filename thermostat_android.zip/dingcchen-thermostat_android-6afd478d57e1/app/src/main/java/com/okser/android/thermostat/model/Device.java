package com.okser.android.thermostat.model;

import java.io.Serializable;

public class Device implements Serializable {
    private String mHost;
    private String mName;
    private String mPrivateName;

    public String getHost() {
        return mHost;
    }

    public void setHost(String host) {
        this.mHost = host;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        this.mName = name;
    }

    public String getPrivateName() {
        return mPrivateName;
    }

    public void setPrivateName(final String privateName) {
        mPrivateName = privateName;
    }
}
