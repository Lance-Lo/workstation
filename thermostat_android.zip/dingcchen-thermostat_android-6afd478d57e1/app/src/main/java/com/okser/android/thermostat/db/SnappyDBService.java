package com.okser.android.thermostat.db;

import android.content.Context;
import android.util.Log;

import com.okser.android.thermostat.model.Location;
import com.okser.android.thermostat.model.LocationList;
import com.snappydb.DB;
import com.snappydb.DBFactory;
import com.snappydb.SnappydbException;

import java.util.List;

public class SnappyDBService {
    private static final String DATABASE_KEY_LOCATIONS = "locations";
    private static final String TAG = SnappyDBService.class.getSimpleName();
    private static SnappyDBService sInstance;
    private LocationList mLocationList;
    private DB mSnappyDB;

    private SnappyDBService(Context context) {
        open(context);
    }

    public static synchronized void clear() {
        sInstance = null;
    }

    public static SnappyDBService getInstance(final Context context) {
        if (sInstance == null) {
            sInstance = new SnappyDBService(context);
        }
        return sInstance;
    }

    private void open(Context context) {
        try {
            mSnappyDB = DBFactory.open(context.getApplicationContext());
            if (mSnappyDB.exists(DATABASE_KEY_LOCATIONS)) {
                mLocationList = mSnappyDB.get(DATABASE_KEY_LOCATIONS, LocationList.class);
            }
            if (mLocationList == null) {
                mLocationList = new LocationList();
                mLocationList.add(new Location());
            }
        } catch (SnappydbException e) {
            Log.e(TAG, "initialize/open database failed: " + e.getMessage(), e);
        }
    }

    public void addLocation(Location location) {
        try {
            mLocationList.add(location);
            if (mSnappyDB != null) {
                mSnappyDB.put(DATABASE_KEY_LOCATIONS, mLocationList);
            }
        } catch (Exception e) {
            Log.e(TAG, "add location failed (1): " + e.getMessage(), e);
        }
    }

    public void destroyDatabase(Context context) {
        try {
            mSnappyDB.destroy();
            open(context);
        } catch (SnappydbException e) {
            Log.e(TAG, "destroy database failed: " + e.getMessage(), e);
        }
    }

    public int getCount() {
        return mLocationList.getData().size();
    }

    public Location getLocation(final int pos) {
        return mLocationList.getData().get(pos);
    }

    public List<Location> getLocationList() {
        return mLocationList.getData();
    }

    public synchronized void updateLocation() {
        try {
            if (mSnappyDB != null) {
                mSnappyDB.put(DATABASE_KEY_LOCATIONS, mLocationList);
            }
        } catch (Exception e) {
            Log.e(TAG, "update location failed (1): " + e.getMessage(), e);
        }
    }
}
