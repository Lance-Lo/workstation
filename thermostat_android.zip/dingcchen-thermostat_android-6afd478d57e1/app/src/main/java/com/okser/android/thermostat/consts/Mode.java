package com.okser.android.thermostat.consts;

public enum Mode {
    Hold, Schedule
}
