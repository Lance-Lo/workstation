package com.okser.android.thermostat.view;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.TimePicker;

import com.okser.android.thermostat.R;
import com.okser.android.thermostat.consts.Consts;
import com.okser.android.thermostat.consts.Mode;
import com.okser.android.thermostat.consts.Unit;
import com.okser.android.thermostat.utils.ITabListener;
import com.okser.android.thermostat.utils.Utils;

public class TStatFragment extends Fragment implements ITabListener, View.OnClickListener, TimePickerDialog.OnTimeSetListener {
    private TextView mCoolText;
    private TextView mHeatText;
    private long mHoldFor;
    private TextView mLabelHold;
    private Mode mMode;
    private CheckBox mModeSwitch;
    private TextView mModeTemperatureDesp;
    private TextView mModeValue;
    private long mOldHoldFor;
    private Mode mOldMode;
    private int mOldPermanentCool;
    private int mOldPermanentHeat;
    private int mOldTemporaryCool;
    private int mOldTemporaryHeat;
    private int mPermanentCool;
    private int mPermanentHeat;
    private int mTemperaryCool;
    private int mTemporaryHeat;
    private Unit mUnit;

    public static TStatFragment newInstance(Bundle extras) {
        Bundle args = new Bundle(extras);
        TStatFragment f = new TStatFragment();
        f.setArguments(args);
        return f;
    }

    @Override
    public boolean doBackAction() {
        return true;
    }

    public void doSave() {
        Bundle result = new Bundle(getArguments());
        result.putInt(Consts.KEY_MODE, mMode.ordinal());
        if (mMode == Mode.Hold) {
            result.putInt(Consts.KEY_PERMANENT_COOL, mPermanentCool);
            result.putInt(Consts.KEY_PERMANENT_HEAT, mPermanentHeat);
            mOldPermanentHeat = mPermanentHeat;
            mOldPermanentCool = mPermanentCool;
        } else {
            result.putInt(Consts.KEY_TEMPORAY_COOL, mTemperaryCool);
            result.putInt(Consts.KEY_TEMPORAY_HEAT, mTemporaryHeat);
            mOldTemporaryHeat = mTemporaryHeat;
            mOldTemporaryCool = mTemperaryCool;
            result.putLong(Consts.KEY_HOLDFOR, mHoldFor);
        }
        Log.i(this.getClass().getSimpleName(), "HOS:" + mHoldFor);
        mOldMode = mMode;
        mOldHoldFor = mHoldFor;
        updateView();
        ConferenceFragment f = (ConferenceFragment) getParentFragment();
        f.saveRequest(result);
    }

    private void updateView() {
        boolean changed = ((mMode != mOldMode)
                || ((mMode == Mode.Hold) && ((mOldPermanentHeat != mPermanentHeat) || (mOldPermanentCool != mPermanentCool)))
                || ((mMode == Mode.Schedule) && ((mOldTemporaryCool != mTemperaryCool) || (mOldTemporaryHeat != mTemporaryHeat) || (mOldHoldFor != mHoldFor))));
        Fragment f = getParentFragment();
        if (f instanceof ConferenceFragment) {
            ((ConferenceFragment) f).updateRightBtn(changed);
        }
    }

    @Override
    public void onClick(final View v) {
        switch (v.getId()) {
            case R.id.labelhold: {
                int hour = (int) (mHoldFor / 60);
                int minu = (int) (mHoldFor % 60);
                TimePickerDialog dialog = new TimePickerDialog(getActivity(), this, hour, minu, true);
                dialog.show();
            }
            break;
            case R.id.coolbtnup:
                if (mMode == Mode.Hold) {
                    if (mPermanentCool < Consts.TEMP_MAX) {
                        mPermanentCool++;
                        setTemperature(mCoolText, mPermanentCool);
                        updateView();
                    }
                } else {
                    if (mTemperaryCool < Consts.TEMP_MAX) {
                        mTemperaryCool++;
                        setTemperature(mCoolText, mTemperaryCool);
                        updateView();
                    }
                }
                break;
            case R.id.coolbtndown:
                if (mMode == Mode.Hold) {
                    if (mPermanentCool > mPermanentHeat) {
                        mPermanentCool--;
                        setTemperature(mCoolText, mPermanentCool);
                        updateView();
                    }
                } else {
                    if (mTemperaryCool > mTemporaryHeat) {
                        mTemperaryCool--;
                        setTemperature(mCoolText, mTemperaryCool);
                        updateView();
                    }
                }
                break;
            case R.id.heatbtnup:
                if (mMode == Mode.Hold) {
                    if (mPermanentHeat < mPermanentCool) {
                        mPermanentHeat++;
                        setTemperature(mHeatText, mPermanentHeat);
                        updateView();
                    }
                } else {
                    if (mTemporaryHeat < mTemperaryCool) {
                        mTemporaryHeat++;
                        setTemperature(mHeatText, mTemporaryHeat);
                        updateView();
                    }
                }
                break;
            case R.id.heatbtndown:
                if (mMode == Mode.Hold) {
                    if (mPermanentHeat > Consts.TEMP_MIN) {
                        mPermanentHeat--;
                        setTemperature(mHeatText, mPermanentHeat);
                        updateView();
                    }
                } else {
                    if (mTemporaryHeat > Consts.TEMP_MIN) {
                        mTemporaryHeat--;
                        setTemperature(mHeatText, mTemporaryHeat);
                        updateView();
                    }
                }
                break;
        }

    }

    private void setTemperature(TextView textView, int temp) {
        Utils.setTemperature(getActivity(), textView, temp, mUnit);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tab_tstat, container, false);
        mHeatText = (TextView) view.findViewById(R.id.heat_text_temperature);
        mCoolText = (TextView) view.findViewById(R.id.cool_text_temperature);
        mModeSwitch = (CheckBox) view.findViewById(R.id.switchmode);
        mModeTemperatureDesp = (TextView) view.findViewById(R.id.temperature_desp);
        mModeValue = (TextView) view.findViewById(R.id.modevalue);
        mLabelHold = (TextView) view.findViewById(R.id.labelhold);
        mLabelHold.setOnClickListener(this);

        View coolup = view.findViewById(R.id.coolbtnup);
        View cooldown = view.findViewById(R.id.coolbtndown);
        View heatup = view.findViewById(R.id.heatbtnup);
        View heatdown = view.findViewById(R.id.heatbtndown);

        coolup.setOnClickListener(this);
        cooldown.setOnClickListener(this);
        heatup.setOnClickListener(this);
        heatdown.setOnClickListener(this);

        buildupData();
        return view;
    }

    private void buildupData() {
        Bundle args = getArguments();
        if (args != null) {
            int unit = args.getInt(Consts.KEY_TEMPERATURE_UNIT);
            if (unit == Unit.F.ordinal()) {
                mUnit = Unit.F;
            } else {
                mUnit = Unit.C;
            }
            mOldTemporaryHeat = args.getInt(Consts.KEY_TEMPORAY_HEAT);
            mOldTemporaryCool = args.getInt(Consts.KEY_TEMPORAY_COOL);
            mOldPermanentHeat = args.getInt(Consts.KEY_PERMANENT_HEAT);
            mOldPermanentCool = args.getInt(Consts.KEY_PERMANENT_COOL);
            int mode = args.getInt(Consts.KEY_MODE);
            if (mode == Mode.Schedule.ordinal()) {
                mOldMode = Mode.Schedule;
            } else {
                mOldMode = Mode.Hold;
            }
            mOldHoldFor = args.getLong(Consts.KEY_HOLDFOR);
        }
        mMode = mOldMode;
        mTemperaryCool = mOldTemporaryCool;
        mTemporaryHeat = mOldTemporaryHeat;
        mPermanentCool = mOldPermanentCool;
        mPermanentHeat = mOldPermanentHeat;
        mHoldFor = mOldHoldFor;
        updateMode();
        mModeSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked) {
                if (isChecked) {
                    mMode = Mode.Schedule;
                } else {
                    mMode = Mode.Hold;
                }
                updateMode();
                updateView();
            }
        });
    }

    private void updateMode() {
        if (mMode == Mode.Hold) {
            mModeSwitch.setChecked(false);
            mModeValue.setText(R.string.label_hold);
            mModeTemperatureDesp.setText(R.string.label_temperature_hold);
            setTemperature(mCoolText, mPermanentCool);
            setTemperature(mHeatText, mPermanentHeat);
            mLabelHold.setVisibility(View.GONE);
        } else {
            mModeSwitch.setChecked(true);
            mModeValue.setText(R.string.label_schedule);
            mModeTemperatureDesp.setText(R.string.label_temperature_followschedle);
            setTemperature(mCoolText, mTemperaryCool);
            setTemperature(mHeatText, mTemporaryHeat);
            setClock(mLabelHold, (int) (mHoldFor / 60), (int) (mHoldFor % 60));
            mLabelHold.setVisibility(View.VISIBLE);
        }
    }

    private void setClock(TextView hold, int hour, int minute) {
        String hourText = hour < 10 ? "0" + hour : String.valueOf(hour);
        String minText = minute < 10 ? "0" + minute : String.valueOf(minute);
        hold.setText(hold.getResources().getString(R.string.label_holdfor) + "  " + hourText + ":" + minText);
    }

    @Override
    public void onTimeSet(final TimePicker view, final int hourOfDay, final int minute) {
        mHoldFor = hourOfDay * 60 + minute;
        setClock(mLabelHold, hourOfDay, minute);
        updateView();
    }
}
