package com.okser.android.thermostat.consts;

public enum Fan {
    Auto, On, Circulate
}
