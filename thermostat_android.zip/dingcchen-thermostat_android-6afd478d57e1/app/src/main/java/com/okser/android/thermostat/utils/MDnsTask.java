package com.okser.android.thermostat.utils;


import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.MulticastLock;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.integrity_project.smartconfiglib.SmartConfig;
import com.integrity_project.smartconfiglib.SmartConfigListener;
import com.okser.android.thermostat.model.Device;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import javax.jmdns.JmDNS;
import javax.jmdns.ServiceEvent;
import javax.jmdns.ServiceListener;
import javax.jmdns.ServiceTypeListener;

public final class MDnsTask extends Thread implements ServiceListener, ServiceTypeListener, SmartConfigListener, Handler.Callback {
    private static final int MES_TIMEUP = 1000;
    private static final String SERVICE_TYPE = "_http._tcp.";
    private static final String SMARTCONFIG_IDENTIFIER = "srcvers=1D90645";
    private static final String TAG = MDnsTask.class.getSimpleName();
    private static final long TIMELIMIIT = 15000;
    private final List<Device> mDevices;
    private final String mGateway;
    private final MDnsCallbackInterface mMdnsCallback;
    private final MulticastLock mMulticastLock;
    private final WifiManager mWifiManager;
    private final String mWifiName;
    private final String mWifiPwd;
    private Handler mHandler;
    private JmDNS mJmdns;
    private SmartConfig mSmartConfig;
    private boolean mStop;

    public MDnsTask(final Context ctx, final MDnsCallbackInterface callback, final String ssid, final String pwd,
                    final String gateway) {
        mMdnsCallback = callback;
        mDevices = new ArrayList<>();
        mWifiManager = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
        mMulticastLock = mWifiManager.createMulticastLock(getClass().getName());
        mMulticastLock.setReferenceCounted(true);
        mStop = false;
        mGateway = gateway;
        mWifiPwd = pwd;
        mWifiName = ssid;
        mHandler = new Handler(this);
        mHandler.sendEmptyMessageDelayed(MES_TIMEUP, TIMELIMIIT);
        start();
    }

    @Override
    public boolean handleMessage(final Message msg) {
        synchronized (this) {
            if (!mStop) {
                mHandler.removeMessages(MES_TIMEUP);
                Log.i(TAG, "stopscan because of timeup");
                stopScan();
            }
        }
        return true;
    }

    public synchronized void stopScan() {
        mHandler.removeMessages(MES_TIMEUP);
        mStop = true;
        this.interrupt();
    }

    @Override
    public void onSmartConfigEvent(SmtCfgEvent arg0, Exception arg1) {
        Log.w(TAG, arg0.toString());
        Log.w(TAG, arg0.toString(), arg1);
    }

    @Override
    public void run() {
        if (!mStop) {
            if (this.mMdnsCallback != null) {
                mMdnsCallback.onDeviceStarted();
            }
            try {
                startDiscover();
            } catch (Exception e) {
                Log.e(TAG, "startDiscover fail!", e);
                mStop = true;
            }
            synchronized (this) {
                try {
                    while (!mStop) {
                        wait();
                    }
                } catch (InterruptedException e) {
                    Log.w(TAG, "discover terminate!");
                } finally {
                    stopDiscovery();
                    if (this.mMdnsCallback != null) {
                        mMdnsCallback.onDeviceStoped(mDevices);
                    }
                }
            }
        }
    }

    private void startDiscover() throws Exception {
        Log.i(TAG, "MDNS start discovery >> ");
        long time = System.currentTimeMillis();
        byte[] freeData = new byte[]{0x03};
        byte[] paddedEncryptionKey = null;
        final InetAddress deviceIpAddress = getDeviceIpAddress(mWifiManager);
        if (!mMulticastLock.isHeld()) {
            mMulticastLock.acquire();
        } else {
            Log.i(TAG, " Muticast lock already held...");
        }
        Log.i(TAG, "MDNS discovery acquire " + (System.currentTimeMillis() - time));
        mSmartConfig = new SmartConfig(this, freeData, this.mWifiPwd, paddedEncryptionKey, this.mGateway,
                this.mWifiName, (byte) 0, "");
        mSmartConfig.transmitSettings();
        mJmdns = JmDNS.create(deviceIpAddress, "SmartConfig");
        mJmdns.addServiceTypeListener(this);
        Log.i(TAG, "MDNS start discovery << " + (System.currentTimeMillis() - time));
    }

    private InetAddress getDeviceIpAddress(WifiManager wifi) {
        InetAddress result = null;
        try {
            // default to Android localhost
            result = InetAddress.getByName("10.0.0.2");

            // figure out our wifi address, otherwise bail
            WifiInfo wifiinfo = wifi.getConnectionInfo();
            int intaddr = wifiinfo.getIpAddress();
            byte[] byteaddr = new byte[]{(byte) (intaddr & 0xff), (byte) (intaddr >> 8 & 0xff),
                    (byte) (intaddr >> 16 & 0xff), (byte) (intaddr >> 24 & 0xff)};
            result = InetAddress.getByAddress(byteaddr);
        } catch (UnknownHostException ex) {
            Log.e(TAG, String.format("getDeviceIpAddress Error: %s", ex.getMessage()));
        }

        return result;
    }

    private void stopDiscovery() {
        Log.i(TAG, "MDNS stop discovery  >> ");
        long time = System.currentTimeMillis();
        try {
            if (mSmartConfig != null) {
                mSmartConfig.stopTransmitting();
                mSmartConfig = null;
            }

            if (mMulticastLock.isHeld()) {
                mMulticastLock.release();
            } else {
                Log.i(TAG, "Multicast lock already released");
            }
            if (mJmdns != null) {
                mJmdns.unregisterAllServices();
                mJmdns.close();
                mJmdns = null;
            }
        } catch (IOException e) {
            Log.e(TAG, "MDNS discovery stopped", e);
        } catch (RuntimeException e) {
            Log.e(TAG, "MDNS discovery stopped", e);
        } catch (Exception e) {
            Log.e(TAG, "MDNS discovery stopped", e);
        }
        Log.i(TAG, "MDNS stop discovery << " + (System.currentTimeMillis() - time));
    }

    @Override
    public void serviceAdded(ServiceEvent service) {
    }

    @Override
    public void serviceRemoved(ServiceEvent service) {
    }

    @Override
    public void serviceResolved(ServiceEvent service) {
        Log.i(TAG, "resolved: " + " nice:" + service.getInfo().getNiceTextString());
        if (service.getInfo().getNiceTextString().contains(SMARTCONFIG_IDENTIFIER)) {
            Device device = new Device();
            final String host = service.getInfo().getHostAddresses()[0];
            device.setHost(host);
            device.setPrivateName(service.getName());
            mDevices.add(device);
            Log.i(TAG, "resolved host:" + service.getInfo().getHostAddresses()[0]);
        }
    }

    public void serviceTypeAdded(ServiceEvent event) {
        // TODO Auto-generated method stub
        if (event.getType().contains(SERVICE_TYPE)) {
            mJmdns.addServiceListener(event.getType(), this);
        }
    }

    public void subTypeForServiceTypeAdded(ServiceEvent event) {
    }
}
