package com.okser.android.thermostat.model;

import com.okser.android.thermostat.consts.Fan;
import com.okser.android.thermostat.consts.System;

public class ThermostatValue {
    private Fan mFan;
    private int mHumidity;
    private System mSystem;
    private int mTemperature;

    public Fan getFan() {
        return mFan;
    }

    public void setFan(final Fan fan) {
        mFan = fan;
    }

    public int getHumidity() {
        return mHumidity;
    }

    public void setHumidity(final int humidity) {
        mHumidity = humidity;
    }

    public System getSystem() {
        return mSystem;
    }

    public void setSystem(final System system) {
        mSystem = system;
    }

    public int getTemperature() {
        return mTemperature;
    }

    public void setTemperature(final int temperature) {
        mTemperature = temperature;
    }

    @Override
    public String toString() {
        return "ThermostatValue{" +
                "mFan=" + mFan +
                ", mHumidity=" + mHumidity +
                ", mSystem=" + mSystem +
                ", mTemperature=" + mTemperature +
                '}';
    }
}
