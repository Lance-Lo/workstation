package com.okser.android.thermostat.consts;

public enum Unit {
    F, C
}
