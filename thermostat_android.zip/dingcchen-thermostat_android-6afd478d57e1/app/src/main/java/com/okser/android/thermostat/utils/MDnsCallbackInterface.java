package com.okser.android.thermostat.utils;


import com.okser.android.thermostat.model.Device;

import java.util.List;

public interface MDnsCallbackInterface {
    void onDeviceStoped(List<Device> devices);

    void onDeviceStarted();
}
