//
//  TemperatureCell.m
//  cws
//
//  Created by soeasyright on 2015/11/22.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "TemperatureCell.h"

#define HeatMax 90
#define HeatMin 44
#define ColdMax 90
#define ColdMin 44
@interface TemperatureCell()

typedef NS_ENUM(NSInteger, CWSTemperatureStaus) {
    CWSTemperatureStausThermostatsModel_Hold = 0,
    CWSTemperatureStausThermostatsModel_Permanent = 1,
    CWSTemperatureStausPeriodStatusModel = 2
};
@property (weak, nonatomic) IBOutlet UILabel *heatLabel;
@property (weak, nonatomic) IBOutlet UILabel *coldLabel;
@property (weak, nonatomic) IBOutlet UIButton *heatUpButton;
@property (weak, nonatomic) IBOutlet UIButton *heatDownButton;
@property (weak, nonatomic) IBOutlet UIButton *coldUpButton;
@property (weak, nonatomic) IBOutlet UIButton *coldDownButton;
@property (assign, nonatomic) CWSTemperatureStaus staus;
@end
@implementation TemperatureCell
+ (CGFloat )heightCell{
    return 155.;
}
- (void)awakeFromNib {
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)heatUP:(id)sender {
    if (_heatValue == HeatMax) {
        return;
    }
    _heatValue++;
    _heatLabel.text = [NSString stringWithFormat:@"%d",_heatValue];
    [self checkLimit];
    [self refreshData];
}
- (IBAction)heatDown:(id)sender {
    if (_heatValue == HeatMin) {
        return;
    }
    _heatValue--;
    _heatLabel.text = [NSString stringWithFormat:@"%d",_heatValue];
    [self checkLimit];
    [self refreshData];
}
- (IBAction)coldUp:(id)sender {
    if (_coldValue == ColdMax) {
        return;
    }
    _coldValue++;
    _coldLabel.text = [NSString stringWithFormat:@"%d",_coldValue];
    [self checkLimit];
    [self refreshData];
}
- (IBAction)coldDown:(id)sender {
    if (_coldValue == ColdMin) {
        return;
    }
    _coldValue--;
    _coldLabel.text = [NSString stringWithFormat:@"%d",_coldValue];
    [self checkLimit];
    [self refreshData];
}

- (void) setCellView:(NSObject *) model AtIndexPath:(NSIndexPath *)indexPath
{
    [self setCellView:model];
}

- (void)setCellView:(NSObject *)mModel
{
    Thermostats *model =(Thermostats *)mModel;
    if (!model.isShowPeriod) {
        NSLog(@"TemperatureCell CWSTemperatureStausThermostatsModel 0");
        if (model.nOperation == CWSOperationType_Hold) {
            _coldValue = model.nPermanentCold;
            _heatValue = model.nPermanentHeat;
            _staus = CWSTemperatureStausThermostatsModel_Hold;
        }
        else {
            _coldValue = model.nTemporaryCold;
            _heatValue = model.nTemporaryHeat;
            _staus = CWSTemperatureStausThermostatsModel_Permanent;
        }
    }
    else
    {
        NSLog(@"TemperatureCell CWSTemperatureStausPeriodStatusModel 1");
        _staus = CWSTemperatureStausPeriodStatusModel;
        PeriodStatusModel *psm = [CWSUtil getPeriodModel:model AtRow:model.chosePeriod];
        if (psm) {
            [self setPeriodView:psm];
        }
    }
    _coldLabel.text = [NSString stringWithFormat:@"%d",_coldValue];
    _heatLabel.text = [NSString stringWithFormat:@"%d",_heatValue];
    [self checkLimit];


}
- (void) setPeriodView:(PeriodStatusModel*) model {
    _coldValue = model.nCold;
    _heatValue = model.nHeat;
}

- (void) checkLimit {
    _coldDownButton.enabled = _coldValue != ColdMin;
    _coldUpButton.enabled = _coldValue != ColdMax && (_heatValue - 1) != _coldValue;
    _heatDownButton.enabled = _heatValue != HeatMin && (_heatValue - 1) != _coldValue;;
    _heatUpButton.enabled = _heatValue != HeatMax;
    
}
- (void) refreshData{
    if (self.delegte && [self.delegte respondsToSelector:@selector(refreshData:)]) {
        NSDictionary * dict = nil;
        switch (_staus) {
            case CWSTemperatureStausThermostatsModel_Hold:
            {
                
                dict =@{@"nPermanentCold":@(_coldValue),
                        @"nPermanentHeat":@(_heatValue)
                        };
            }
                break;
            case CWSTemperatureStausThermostatsModel_Permanent:
            {
                dict =@{@"nTemporaryCold":@(_coldValue),
                        @"nTemporaryHeat":@(_heatValue)
                        };
            }
                break;
            case CWSTemperatureStausPeriodStatusModel:
            {
                dict =@{@"nHeat":@(_heatValue),
                        @"nCold":@(_coldValue)
                        };
            }
                break;
                
            default:
                break;
        }
        [self.delegte refreshData:dict];
    }
}
@end
