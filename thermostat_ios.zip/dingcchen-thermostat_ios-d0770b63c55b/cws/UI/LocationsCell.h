//
//  LocationsCell.h
//  cws
//
//  Created by soeasyright on 2015/11/21.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationsCell : OKSerTableViewCell
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UIView *selectBox;
@property (weak, nonatomic) IBOutlet UIButton *locationIcon;
@property (weak, nonatomic) IBOutlet UIButton *thermostatsIcon;
@property (weak, nonatomic) IBOutlet UILabel *thermostatNum;
@property (assign,nonatomic) NSInteger cellRow;


@end
