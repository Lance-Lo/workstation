//
//  WeekCell.h
//  cws
//
//  Created by soeasyright on 2015/11/23.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeekCell : OKSerTableViewCell
- (void) setAllRadioEnable:(BOOL)enable;
@property (nonatomic,assign) CWSWeekCellStatus nowWeekStatus;
@end
