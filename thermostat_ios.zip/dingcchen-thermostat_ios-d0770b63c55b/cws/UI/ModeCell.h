//
//  ModeCell.h
//  cws
//
//  Created by soeasyright on 2015/11/22.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModeCell : OKSerTableViewCell
@property (nonatomic,assign) NSInteger holdMin;
@property (nonatomic,assign) NSInteger holdHour;
@property (nonatomic, assign) CWSOperationType operation;
@end
