//
//  RadioCell.h
//  cws
//
//  Created by soeasyright on 2015/11/24.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RadioCell : OKSerTableViewCell
@property (weak, nonatomic) IBOutlet UIButton *radioButton;
@property (weak, nonatomic) IBOutlet UILabel *radioLabel;
@property (weak, nonatomic) IBOutlet UIView *splitLine;

@end
