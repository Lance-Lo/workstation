//
//  SetTimeCell.h
//  cws
//
//  Created by soeasyright on 2015/11/25.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetTimeCell : OKSerTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (nonatomic,assign) NSInteger nMin;
@property (nonatomic,assign) NSInteger nHour;
@end
