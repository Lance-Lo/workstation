//
//  TitleCell.m
//  cws
//
//  Created by soeasyright on 2015/11/24.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "TitleCell.h"

@implementation TitleCell
+ (CGFloat )heightCell{
    return 55.;
}
- (void)setCellInfo:(NSString *)mInfo
{
    _titleLabel.text = mInfo;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
