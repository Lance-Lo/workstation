//
//  SetTimeCell.m
//  cws
//
//  Created by soeasyright on 2015/11/25.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "SetTimeCell.h"

#import "LGAlertView.h"
@implementation SetTimeCell
+ (CGFloat )heightCell{
    return 60.;
}
- (void)setCellView:(NSObject *)mModel
{
    Thermostats *model =(Thermostats *)mModel;
    PeriodStatusModel *psm = [CWSUtil getPeriodModel:model AtRow:model.chosePeriod];
    if (psm) {
        [self setPeriodView:psm];
    }
}
- (void) setPeriodView:(PeriodStatusModel*) model {
    _nHour = model.nHour;
    _nMin = model.nMin;
    NSString *AM = _nHour<12 ?@"AM":@"PM";
    NSInteger showHour =  _nHour<12 ? _nHour:_nHour-12;
    _timeLabel.text = [NSString stringWithFormat:@"%02d:%02d %@",showHour,_nMin,AM];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    if(!selected){
        return;
    }
        
    UIDatePicker *datePicker = [UIDatePicker new];
    datePicker.datePickerMode = UIDatePickerModeTime;
    datePicker.frame = CGRectMake(0.f, 0.f, datePicker.frame.size.width, 160.f);
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"HH:mm";
    datePicker.date = [formatter dateFromString:[NSString stringWithFormat:@"%02d:%02d",_nHour,_nMin]];
//

    [[[LGAlertView alloc] initWithViewAndTitle:@"DatePicker"
                                       message:nil
                                         style:LGAlertViewStyleAlert
                                          view:datePicker
                                  buttonTitles:@[@"Done"]
                             cancelButtonTitle:@"Cancel"
                        destructiveButtonTitle:nil
                                 actionHandler:^(LGAlertView *alertView, NSString *title, NSUInteger index) {
                                     NSLog(@"%@", [NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]]);
                                     _nHour = [[[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]] substringToIndex:2] intValue];
                                     _nMin = [[[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]] substringFromIndex:3] intValue];
                                     NSString *AM = _nHour<12 ?@"AM":@"PM";
                                     NSInteger showHour =  _nHour<12 ? _nHour:_nHour-12;
                                     _timeLabel.text = [NSString stringWithFormat:@"%02d:%02d %@",showHour,_nMin,AM];
                                     if (self.delegte && [self.delegte respondsToSelector:@selector(refreshData:)]) {
                                         [self.delegte refreshData:@{@"nHour":@(_nHour),
                                                                     @"nMin":@(_nMin)
                                                                     }];
                                     }
                                     
                                 }
                                 cancelHandler:^(LGAlertView *alertView) {
                                     NSLog(@"cancelHandler");
                                 }
                            destructiveHandler:^(LGAlertView *alertView) {
                                NSLog(@"destructiveHandler");
                            }] showAnimated:YES completionHandler:nil];
    // Configure the view for the selected state
}

@end
