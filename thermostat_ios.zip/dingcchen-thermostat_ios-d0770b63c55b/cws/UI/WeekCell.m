//
//  WeekCell.m
//  ;
//
//  Created by soeasyright on 2015/11/23.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "WeekCell.h"

@interface WeekCell()
@property (weak, nonatomic) IBOutlet UIButton *fiveButton;
@property (weak, nonatomic) IBOutlet UIButton *sixButton;
@property (weak, nonatomic) IBOutlet UIButton *sevenButton;
@property (weak, nonatomic) IBOutlet UIImageView *w1ImageView;
@property (weak, nonatomic) IBOutlet UIImageView *w2ImageView;
@property (weak, nonatomic) IBOutlet UIImageView *w3ImageView;
@property (weak, nonatomic) IBOutlet UIImageView *w4ImageView;
@property (weak, nonatomic) IBOutlet UIImageView *w5ImageView;
@property (weak, nonatomic) IBOutlet UIImageView *w6ImageView;
@property (weak, nonatomic) IBOutlet UIImageView *w7ImageView;

@end
@implementation WeekCell

+ (CGFloat )heightCell{
    return 120.;
}
- (void)awakeFromNib {

}

- (void) setCellView:(NSObject *) model AtIndexPath:(NSIndexPath *)indexPath
{
    [self setCellView:model];
}
- (void)setCellView:(NSObject *)mModel
{
     Thermostats *model =(Thermostats *)mModel;
    [self resetViewWithWeekType:model.nWeekStatus];
}
- (void) resetViewWithWeekType:(CWSWeekCellStatus) type{
    
    switch (type) {
        case CWSWeekCellStatus_5_2_now_5:
        {
            [_fiveButton setSelected:YES];
            [_sixButton setSelected:NO];
            [_sevenButton setSelected:NO];
            [self Day5light:YES];
        }
            break;
        case CWSWeekCellStatus_6_1_now_6:
        {
            [_fiveButton setSelected:NO];
            [_sixButton setSelected:YES];
            [_sevenButton setSelected:NO];
            [self Day6light:YES];
        }
            break;
        case CWSWeekCellStatus_7_now_7:
        {
            [_fiveButton setSelected:NO];
            [_sixButton setSelected:NO];
            [_sevenButton setSelected:YES];
            [self Day7light:YES];
        }
            break;
        case CWSWeekCellStatus_5_2_now_2:
        {
            [_fiveButton setSelected:YES];
            [_sixButton setSelected:NO];
            [_sevenButton setSelected:NO];
            [self Day5light:NO];
        }
            break;
        case CWSWeekCellStatus_6_1_now_1:
        {
            [_fiveButton setSelected:NO];
            [_sixButton setSelected:YES];
            [_sevenButton setSelected:NO];
            [self Day6light:NO];
        }
            break;
        default:
            break;
    }
    _nowWeekStatus = type;
    

}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setAllRadioEnable:(BOOL)enable{
    if (enable) {
        if (!_fiveButton.isEnabled) {
            [_fiveButton setEnabled:YES];
            [_fiveButton setSelected:YES];
        }
        if (!_sixButton.isEnabled) {
            [_sixButton setEnabled:YES];
            [_sixButton setSelected:YES];
        }
        if (!_sevenButton.isEnabled) {
            [_sevenButton setEnabled:YES];
            [_sevenButton setSelected:YES];
        }

    }
    else{
        if (_fiveButton.isSelected) {
            [_fiveButton setSelected:NO];
            [_fiveButton setEnabled:NO];
        }
        if (_sixButton.isSelected) {
            [_sixButton setSelected:NO];
            [_sixButton setEnabled:NO];
        }
        if (_sevenButton.isSelected) {
            [_sevenButton setSelected:NO];
            [_sevenButton setEnabled:NO];
        }
    }
    [self setUserInteractionEnabled:enable];

}

- (IBAction)fiveButtonClicked:(id)sender
{
    BOOL isRefresh = NO;
    switch (_nowWeekStatus) {
        case CWSWeekCellStatus_5_2_now_5:
        {
            
        }
            break;
        case CWSWeekCellStatus_5_2_now_2:
        {
            
        }
            break;
        case CWSWeekCellStatus_6_1_now_6:
        {
            _nowWeekStatus = CWSWeekCellStatus_5_2_now_5;
            isRefresh = YES;
        }
            break;
        case CWSWeekCellStatus_6_1_now_1:
        {
            _nowWeekStatus = CWSWeekCellStatus_5_2_now_2;
            isRefresh = YES;
        }
            break;
        case CWSWeekCellStatus_7_now_7:
        {
            _nowWeekStatus = CWSWeekCellStatus_5_2_now_5;
            isRefresh = YES;
        }
            break;
        default:
            break;
    }
    if (isRefresh) {
        if (self.delegte && [self.delegte respondsToSelector:@selector(refreshData:)]) {
            [self.delegte refreshData:@{@"nWeekType":@(CWSProgramOptionsType_5_2),
                                        @"nWeekStatus":@(_nowWeekStatus)
                                        
                                        }];
        }
    }
}
- (IBAction)sixButtonClicked:(id)sender
{
    BOOL isRefresh = NO;
    switch (_nowWeekStatus) {
        case CWSWeekCellStatus_5_2_now_5:
        {
            _nowWeekStatus = CWSWeekCellStatus_6_1_now_6;
            isRefresh = YES;
        }
            break;
        case CWSWeekCellStatus_5_2_now_2:
        {
            _nowWeekStatus = CWSWeekCellStatus_6_1_now_1;
            isRefresh = YES;
        }
            break;
        case CWSWeekCellStatus_6_1_now_6:
        {


        }
            break;
        case CWSWeekCellStatus_6_1_now_1:
        {
            
            
        }
            break;
        case CWSWeekCellStatus_7_now_7:
        {
            _nowWeekStatus = CWSWeekCellStatus_6_1_now_6;
            isRefresh = YES;
        }
            break;
        default:
            break;
    }
    if (isRefresh) {
        if (self.delegte && [self.delegte respondsToSelector:@selector(refreshData:)]) {
            [self.delegte refreshData:@{@"nWeekType":@(CWSProgramOptionsType_6_1),
                                        @"nWeekStatus":@(_nowWeekStatus)}];
            
        }
    }
}
- (IBAction)sevenButtonClicked:(id)sender
{
    
    BOOL isRefresh = NO;
    switch (_nowWeekStatus) {
        case CWSWeekCellStatus_7_now_7:
        {


        }
            break;
        default:
        {
            _nowWeekStatus = CWSWeekCellStatus_7_now_7;
            isRefresh = YES;
        }
            break;
    }
    if (isRefresh) {
        if (self.delegte && [self.delegte respondsToSelector:@selector(refreshData:)]) {
            [self.delegte refreshData:@{@"nWeekType":@(CWSProgramOptionsType_7),
                                        @"nWeekStatus":@(_nowWeekStatus)
                                        }];
        }
    }

}
- (void) Day5light:(BOOL)light{
    [_w1ImageView setHighlighted:!light];
    [_w2ImageView setHighlighted:!light];
    [_w3ImageView setHighlighted:!light];
    [_w4ImageView setHighlighted:!light];
    [_w5ImageView setHighlighted:!light];
    [_w6ImageView setHighlighted:light];
    [_w7ImageView setHighlighted:light];
}
- (void) Day6light:(BOOL)light{
    [_w1ImageView setHighlighted:!light];
    [_w2ImageView setHighlighted:!light];
    [_w3ImageView setHighlighted:!light];
    [_w4ImageView setHighlighted:!light];
    [_w5ImageView setHighlighted:!light];
    [_w6ImageView setHighlighted:!light];
    [_w7ImageView setHighlighted:light];
}
- (void) Day7light:(BOOL)light{
    [_w1ImageView setHighlighted:!light];
    [_w2ImageView setHighlighted:!light];
    [_w3ImageView setHighlighted:!light];
    [_w4ImageView setHighlighted:!light];
    [_w5ImageView setHighlighted:!light];
    [_w6ImageView setHighlighted:!light];
    [_w7ImageView setHighlighted:!light];
}
@end
