//
//  ThermostatsCell.m
//  cws
//
//  Created by soeasyright on 2015/11/21.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "ThermostatsCell.h"

@implementation ThermostatsCell
+ (CGFloat )heightCell{
    return 175.;
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setCellView:(NSObject *)mModel
{
    Thermostats *model =(Thermostats *)mModel;
    _thermostatName.text = model.displayName;
    _degreeLabel.text = [model.nDegree stringByAppendingString:@"°F"];
    _humdityLabel.text = [model.nHumidity stringByAppendingString:@"%"];
    _systemLabel.text = [Thermostats tableForSystem:model.nSystem];
    _fanLabel.text = [Thermostats tableForFan:model.nFan];

}
@end
