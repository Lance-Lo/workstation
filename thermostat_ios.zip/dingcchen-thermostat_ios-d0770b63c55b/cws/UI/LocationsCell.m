//
//  LocationsCell.m
//  cws
//
//  Created by soeasyright on 2015/11/21.
//  Copyright © 2015年 okser. All rights reserved.
//


#import "Location.h"
#import "LocationsCell.h"
@implementation LocationsCell
+ (CGFloat )heightCell{
    return 100.;
}

- (void) setCellView:(NSObject *) model AtIndexPath:(NSIndexPath *)indexPath
{
    _cellRow = indexPath.row;
    [self setCellView:model];
}
- (void)setCellView:(NSObject *)mModel
{
    Location *model =(Location *)mModel;
    
    _nameTextField.text = model.displayName;
    _thermostatNum.text = [NSString stringWithFormat:@"%d",model.thermostatsNum ];
    if (model.thermostatsNum == 0) {
        [_nameTextField setTextColor:[UIColor grayColor]];
        [_thermostatNum setTextColor:[UIColor grayColor]];
    }
    else
    {
        [_nameTextField setTextColor:[UIColor blackColor]];
        [_thermostatNum setTextColor:[UIColor blackColor]];
    }
    //    _nameTextField.text = model.locationName;
    //    _nameTextField.text = model.locationName;
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)onIconButton:(id)sender {
    if (self.delegte && [self.delegte respondsToSelector:@selector(refreshData:)]) {
        [self.delegte refreshData:@{@"onIconButton":@(1),
                                    @"CellRow":@(_cellRow)
                                    }];
    }
}
- (IBAction)onThermostatsButton:(id)sender {
    if (self.delegte && [self.delegte respondsToSelector:@selector(refreshData:)]) {
        [self.delegte refreshData:@{@"onIconButton":@(0),
                                    @"CellRow":@(_cellRow)
                                    }];
    }
}

@end
