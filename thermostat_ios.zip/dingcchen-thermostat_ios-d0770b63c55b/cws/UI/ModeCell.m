//
//  ModeCell.m
//  cws
//
//  Created by soeasyright on 2015/11/22.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "ModeCell.h"

#import "LGAlertView.h"
@interface ModeCell()
@property (weak, nonatomic) IBOutlet UIButton *scheduleButton;
@property (weak, nonatomic) IBOutlet UILabel *scheduleLabel;
@property (weak, nonatomic) IBOutlet UILabel *remainTime;
@property (weak, nonatomic) IBOutlet UIImageView *timeImg;
@property (weak, nonatomic) IBOutlet UIButton *timeButton;
@property (weak, nonatomic) IBOutlet UILabel *holdForLabel;
@property (nonatomic, assign) BOOL isScheduel;
@property (nonatomic, strong) NSTimer *countdownTimer;
@end
@implementation ModeCell
+ (CGFloat )heightCell{
    return 135.;
}

- (void)setCellView:(NSObject *)mModel
{
    Thermostats *model =(Thermostats *)mModel;
    _operation = model.nOperation;
    _holdMin = model.nHoldMin % 60;
    _holdHour = model.nHoldMin / 60;
    switch (_operation) {
        case CWSOperationType_Hold:
        {
            [self onClickSchedule:NO];
            
        }
            break;
        case CWSOperationType_Schedule:
        {
            [self onClickSchedule:YES];
            
        }
            break;
        default:
            break;
    }
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)scheduleSwitch:(id)sender {
    BOOL on = !_isScheduel;
    [self onClickSchedule:on];
    if (self.delegte && [self.delegte respondsToSelector:@selector(refreshData:)]) {
        [self.delegte refreshData:@{@"nOperation":@(on)}];
    }
    
}

- (void)onClickSchedule:(BOOL)on{
    _isScheduel=on;
    _scheduleButton.selected = on;
    [_timeImg setHighlighted:on];
    _timeButton.enabled = on;
    if (on) {
        _remainTime.text = [NSString stringWithFormat:@"%02d : %02d",_holdHour,_holdMin];
        _scheduleLabel.text = @"Run Schedule";
        _remainTime.hidden = !on;
        _timeImg.hidden = !on;
        _timeButton.hidden = !on;
        _remainTime.hidden = !on;
        _holdForLabel.hidden = !on;
        _countdownTimer = [NSTimer scheduledTimerWithTimeInterval:(float)60.0 target:self selector:@selector(countdownFunction:) userInfo:nil repeats:YES];
    }
    else {
        _scheduleLabel.text = @"Permanent Hold";
        
        _remainTime.hidden = !on;
        _timeImg.hidden = !on;
        _timeButton.hidden = !on;
        _remainTime.hidden = !on;
        _holdForLabel.hidden = !on;
        if (_countdownTimer) {
            [_countdownTimer invalidate];
            _countdownTimer = nil;
        }
//        _remainTime.text = @"00 : 00";
//        _scheduleLabel.text = @"Hold";
    }
}
-(void)countdownFunction:(NSTimer *)timer
{
    _holdMin--;
    if (_holdMin < 0) {
        _holdMin = 59;
        _holdHour--;
        if (_holdHour < 0) {
            _holdHour = 0;
            _holdMin = 0;
            [_countdownTimer invalidate];
            _countdownTimer = nil;
        }
    }
    _remainTime.text = [NSString stringWithFormat:@"%02d : %02d",_holdHour,_holdMin];
}
- (IBAction)setTime:(id)sender {
    UIDatePicker *datePicker = [[UIDatePicker alloc] init];
    datePicker.datePickerMode = UIDatePickerModeTime;
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setLocalizedDateFormatFromTemplate:@"HH:mm"];
    datePicker.locale = [NSLocale localeWithLocaleIdentifier:@"en_GB"];
    datePicker.date = [formatter dateFromString:[NSString stringWithFormat:@"%02d:%02d",_holdHour,_holdMin]];
    datePicker.frame = CGRectMake(0.f, 0.f, datePicker.frame.size.width, 160.f);
    
    [[[LGAlertView alloc] initWithViewAndTitle:@"Set time"
                                       message:nil
                                         style:LGAlertViewStyleAlert
                                          view:datePicker
                                  buttonTitles:@[@"Done"]
                             cancelButtonTitle:@"Cancel"
                        destructiveButtonTitle:nil
                                 actionHandler:^(LGAlertView *alertView, NSString *title, NSUInteger index) {
                                     NSLog(@"actionHandler, %@, %lu", title, (long unsigned)index);
                                     NSLog(@"%@", [NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]]);
                                     
                                     _holdHour = [[[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]] substringToIndex:2] intValue];
                                     _holdMin = [[[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]] substringFromIndex:3] intValue];
                                     _remainTime.text = [NSString stringWithFormat:@"%02d : %02d",_holdHour,_holdMin];
                                     if (self.delegte && [self.delegte respondsToSelector:@selector(refreshData:)]) {
                                         [self.delegte refreshData:@{@"nHoldMin":@(_holdHour*60+_holdMin)}];
                                     }
                                 }
                                 cancelHandler:^(LGAlertView *alertView) {
                                     NSLog(@"cancelHandler");
                                 }
                            destructiveHandler:nil] showAnimated:YES completionHandler:nil];

}

@end
