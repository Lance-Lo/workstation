//
//  ThermostatsCell.h
//  cws
//
//  Created by soeasyright on 2015/11/21.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ThermostatsCell : OKSerTableViewCell
@property (weak, nonatomic) IBOutlet UITextField *thermostatName;
@property (weak, nonatomic) IBOutlet UILabel *degreeLabel;
@property (weak, nonatomic) IBOutlet UILabel *humdityLabel;
@property (weak, nonatomic) IBOutlet UILabel *systemLabel;
@property (weak, nonatomic) IBOutlet UILabel *fanLabel;
@property (weak, nonatomic) IBOutlet UIView *selectBox;

@end
