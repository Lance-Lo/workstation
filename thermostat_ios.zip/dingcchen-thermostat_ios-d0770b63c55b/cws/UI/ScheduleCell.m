//
//  ScheduleCell.m
//  cws
//
//  Created by soeasyright on 2015/11/24.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "ScheduleCell.h"

@interface ScheduleCell()


@end

@implementation ScheduleCell

+ (CGFloat )heightCell{
    return 60.;
}
- (void)setCellInfo:(NSString *)mInfo
{
    _titleLabel.text = mInfo;
    
}

- (void) setCellView:(NSObject *) mModel AtIndexPath:(NSIndexPath *)indexPath
{
    Thermostats *model =(Thermostats *)mModel;
    PeriodStatusModel *periodModel = [CWSUtil getPeriodModel:model AtRow:indexPath.row];
    [self setPeriodView:periodModel];
}


- (void) setPeriodView:(PeriodStatusModel*) model {

    NSString *AM = model.nHour<12 ?@"AM":@"PM";
    NSInteger showHour =  model.nHour<12 ? model.nHour:model.nHour-12;
    _timeLabel.text = [NSString stringWithFormat:@"%02d:%02d %@",showHour,model.nMin,AM];
    _heatLabel.text = [NSString stringWithFormat:@"%2d°F",model.nHeat];
    _coldLabel.text = [NSString stringWithFormat:@"%2d°F",model.nCold];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
