//
//  NextSettingCell.m
//  cws
//
//  Created by soeasyright on 2015/11/24.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "NextSettingCell.h"

@interface NextSettingCell()
@property (weak, nonatomic) IBOutlet UILabel *settingLabel;
@property (weak, nonatomic) IBOutlet UIImageView *arrowRight;
@property (weak, nonatomic) IBOutlet UIImageView *arrowLeft;

@end
@implementation NextSettingCell
+ (CGFloat )heightCell{
    return 70.;
}

- (void) setCellView:(NSObject *) model AtIndexPath:(NSIndexPath *)indexPath
{
    [self setCellView:model];
}
- (void)setCellView:(NSObject *)mModel
{
    Thermostats *model =(Thermostats *)mModel;
    [self setWeekType:model.nWeekStatus];
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void) setWeekType:(CWSWeekCellStatus) type
{
    switch (type) {
        case CWSWeekCellStatus_5_2_now_5:
        {
            _settingLabel.text = @"Settings For Sat,Sun";
            _arrowRight.hidden = NO;
            _arrowLeft.hidden = YES;
        }
            break;
        case CWSWeekCellStatus_5_2_now_2:
        {
            _settingLabel.text = @"Settings For\nMon,Tues,Wed,Thur,Fri";
            _arrowRight.hidden = YES;
            _arrowLeft.hidden = NO;
        }
            break;
        case CWSWeekCellStatus_6_1_now_6:
        {
            _settingLabel.text = @"Settings For Sun";
            _arrowRight.hidden = NO;
            _arrowLeft.hidden = YES;
        }
            break;
        case CWSWeekCellStatus_6_1_now_1:
        {
            _settingLabel.text = @"Settings For\nMon,Tues,Wed,Thur,Fri,Sat";
            _arrowRight.hidden = YES;
            _arrowLeft.hidden = NO;
        }
            break;
        case CWSWeekCellStatus_7_now_7:
        {
            _settingLabel.text = @"";
            _arrowRight.hidden = YES;
            _arrowLeft.hidden = YES;
        }
            break;
            
        default:
            break;
    }
}
@end
