//
//  ScheduleCell.h
//  cws
//
//  Created by soeasyright on 2015/11/24.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>




@interface ScheduleCell : OKSerTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *heatLabel;
@property (weak, nonatomic) IBOutlet UILabel *coldLabel;

@end
