//
//  RadioCell.m
//  cws
//
//  Created by soeasyright on 2015/11/24.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "RadioCell.h"

@implementation RadioCell
+(CGFloat )heightCell{
    return 50.;
}

- (void) setCellView:(NSObject *) mModel AtIndexPath:(NSIndexPath *)indexPath
{
    Thermostats *model =(Thermostats *)mModel;
    if (indexPath.section == 0) {
        [self.radioButton setSelected: model.nSystem == [CWSUtil tableSystem:indexPath.row]];
        self.splitLine.hidden = indexPath.row <= CWSSystemType_Auto;
    }
    else if (indexPath.section == 1) {
       [self.radioButton setSelected: model.nFan == [CWSUtil tableFan:indexPath.row]];
        self.splitLine.hidden = indexPath.row <= CWSSystemType_Circulate;
    }
}



- (void)setCellInfo:(NSString *)mInfo
{
    _radioLabel.text = mInfo;
    
}
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}
- (void)setCellView:(NSObject *)mModel
{
//    ThermostatsModel *model =(ThermostatsModel *)mModel;
}

@end
