//
//  ViewController.h
//  cws
//
//  Created by soeasyright on 2015/11/21.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationsViewController : UITableViewController


@end

