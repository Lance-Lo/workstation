//
//  ScheduleTabViewController.m
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "ScheduleTabViewController.h"
#import "HeaderCell.h"

@interface ScheduleTabViewController ()<OKSerCellDelege,OKSerServerDelege>

@end

@implementation ScheduleTabViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[WeekCell nib] forCellReuseIdentifier:[WeekCell Identifier]];
    [self.tableView registerNib:[ScheduleCell nib] forCellReuseIdentifier:[ScheduleCell Identifier]];
    [self.tableView registerNib:[NextSettingCell nib] forCellReuseIdentifier:[NextSettingCell Identifier]];
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedRightButton:)];
    [swipeLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
    [self.view addGestureRecognizer:swipeLeft];
    
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedLeftButton:)];
    [swipeRight setDirection:UISwipeGestureRecognizerDirectionRight];
    [self.view addGestureRecognizer:swipeRight];
}
- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.navigationItem.title = [OKSerServer sharedInstance].singleThermostat.displayName;
    [self showSumitButton:NO];
    [self.tableView reloadData];
    [self.tabBarController.navigationItem setLeftBarButtonItem:[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_back"] landscapeImagePhone:nil style:UIBarButtonItemStyleDone target:self action:@selector(onBackButton:)]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)tappedRightButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    [self.tabBarController setSelectedIndex:selectedIndex + 1];
//    CATransition *anim= [CATransition animation];
//    [anim setType:kCATransitionMoveIn];
//    [anim setSubtype:kCATransitionFromRight];
//    [anim setDuration:0.25];
    //    [anim setTimingFunction:[CAMediaTimingFunction functionWithName:
    //                             kCAMediaTimingFunctionEaseIn]];
//    [self.tabBarController.view.layer addAnimation:anim forKey:@"fadeTransition"];
}

- (IBAction)tappedLeftButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    
    [self.tabBarController setSelectedIndex:selectedIndex - 1];
//    CATransition *anim= [CATransition animation];
//    [anim setType:kCATransitionMoveIn];
//    [anim setSubtype:kCATransitionFromLeft];
//    
//    [anim setDuration:0.25];
    //    [anim setTimingFunction:[CAMediaTimingFunction functionWithName:
    //                             kCAMediaTimingFunctionEaseIn]];
//    [self.tabBarController.view.layer addAnimation:anim forKey:@"fadeTransition"];
}
#pragma mark - <UITableViewDataSource>

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [OKSerServer getSectionFromViewClass:[self class]];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [OKSerServer getSectionFromViewClass:[self class] numberOfRowsInSection:section];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    OKSerTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:[[OKSerServer getClassFromViewClass:[self class] atIndex:indexPath ] Identifier] forIndexPath:indexPath];
    if ([cell class] == [WeekCell class]) {
        WeekCell *weekCell= (WeekCell *)cell;
        [weekCell setAllRadioEnable:YES];
    }
    if ([cell class] == [ScheduleCell class]) {
         [cell setCellInfo:[OKSerServer getInfoFromViewClass:[self class] atIndex:indexPath]];
    }
    [cell setCellView:[OKSerServer sharedInstance].singleThermostat AtIndexPath:indexPath];
    cell.delegte = self;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.section==1) {
        [OKSerServer sharedInstance].singleThermostat.chosePeriod = indexPath.row;
        [self performSegueWithIdentifier:@"Schedule2Period" sender:indexPath];

    }
    if (indexPath.section==2) {
        CWSWeekCellStatus oldStatus = [OKSerServer sharedInstance].singleThermostat.nWeekStatus;
        switch (oldStatus) {
            case CWSWeekCellStatus_5_2_now_5:
            {
                [OKSerServer sharedInstance].singleThermostat.nWeekStatus = CWSWeekCellStatus_5_2_now_2;
            }
                break;
            case CWSWeekCellStatus_5_2_now_2:
            {
                [OKSerServer sharedInstance].singleThermostat.nWeekStatus = CWSWeekCellStatus_5_2_now_5;
            }
                break;
            case CWSWeekCellStatus_6_1_now_6:
            {
                [OKSerServer sharedInstance].singleThermostat.nWeekStatus = CWSWeekCellStatus_6_1_now_1;
            }
                break;
            case CWSWeekCellStatus_6_1_now_1:
            {
                [OKSerServer sharedInstance].singleThermostat.nWeekStatus = CWSWeekCellStatus_6_1_now_6;
            }
                break;
            default:
                break;
        }
        if (oldStatus != [OKSerServer sharedInstance].singleThermostat.nWeekStatus) {
            [self.tableView reloadData];
        }
    }
  
    
}

#pragma mark - <UITableViewDelegate>
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [[OKSerServer getClassFromViewClass:[self class] atIndex:indexPath ] heightCell];
}
#pragma mark - onButtonClicked
- (void)onBackButton:(id)sender{
    if ([OKSerServer sharedInstance].isNeedSubmit) {
        [self showSumitButton:NO];
        [[OKSerServer sharedInstance] showAlertWithBackButtonOnViewConrtoller:self];
        return;
    }
    [self.tabBarController.navigationController popViewControllerAnimated:YES];
}
- (void)refreshData:(NSDictionary*) dict{
    [self showSumitButton:[[OKSerServer sharedInstance] isNeedSumbitForSetThermostatValue:dict]];
    [self.tableView reloadData];
    
}
- (void) showSumitButton:(BOOL)show{
    if (show) {
        if (![self.tabBarController.navigationItem rightBarButtonItem]) {
            [self.tabBarController.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_ok"] landscapeImagePhone:nil style:UIBarButtonItemStyleDone target:self action:@selector(onRightButton:) ] animated:YES];
        }
    }
    else
    {
        [self.tabBarController.navigationItem setRightBarButtonItem:nil];
    }
    
}
-(void)onRightButton:(id)sender{
    [[OKSerServer sharedInstance] saveDataToThermostats];
    [self showSumitButton:NO];
}
@end
