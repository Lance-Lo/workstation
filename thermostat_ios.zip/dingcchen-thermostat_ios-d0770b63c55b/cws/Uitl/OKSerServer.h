//
//  OKSerServer.h
//  cws
//
//  Created by soeasyright on 2015/11/25.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>


@protocol OKSerServerDelege<NSObject>
- (void)onBackButton:(id)sender;
@end
@interface OKSerServer : NSObject
@property (nonatomic, strong) NSArray *location;
@property (atomic, strong) NSArray *thermostats;
@property (nonatomic, weak) Thermostats *singleThermostat;
@property (nonatomic, assign) NSInteger choseLocation;
@property (nonatomic, assign) NSInteger choseThermostats;
@property (nonatomic, assign) BOOL isNeedSubmit;
@property (nonatomic, assign) id<OKSerServerDelege> delega;
+ (instancetype) sharedInstance;
+ (Class) getClassFromViewClass:(Class)viewClass atIndex:(NSIndexPath*) index;
+ (NSInteger) getSectionFromViewClass:(Class)viewClass;
+ (NSInteger) getSectionFromViewClass:(Class)viewClass numberOfRowsInSection:(NSInteger)section;
+ (NSString *) getInfoFromViewClass:(Class)viewClass atIndex:(NSIndexPath*) index;
+ (NSString *) getPeriodNameAtRow:(NSInteger) index;
- (void) showAlertWithBackButtonOnViewConrtoller:(UIViewController *)viewController;
- (void) showAlertWithIndex:(NSInteger)index onTabBarConrtoller:(UITabBarController *)tabbarController;
- (BOOL) isNeedSumbitForSetThermostatValue:(NSDictionary *) dict;
- (BOOL) isNeedSumbitForSetPeriodValueByDict:(NSDictionary *) dict;
- (void) loadAllData;
- (void) loadLocationDataFromDB;
- (void) loadThermostatsDataFromDB;
- (void) saveDataToThermostats;
- (BOOL) addNewThermostatWithSSID:(NSString *)ssid andPassword:(NSString *)password;

@end
