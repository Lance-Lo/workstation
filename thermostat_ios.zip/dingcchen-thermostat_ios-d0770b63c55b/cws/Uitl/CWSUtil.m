//
//  CWSUtil.m
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "CWSUtil.h"

@implementation CWSUtil

+ (PeriodStatusModel *) getPeriodModel:(NSObject *) mModel AtRow:(NSInteger )row
{
    Thermostats *model =(Thermostats *)mModel;
    
    
    switch (model.nWeekStatus) {
        case CWSWeekCellStatus_5_2_now_5:
        case CWSWeekCellStatus_6_1_now_6:
        case CWSWeekCellStatus_7_now_7:
        {
            return [CWSUtil getPeriodModel:model.nSc1 withRow:row];
        }
            break;
        case CWSWeekCellStatus_5_2_now_2:
        case CWSWeekCellStatus_6_1_now_1:
        {
            return [CWSUtil getPeriodModel:model.nSc2 withRow:row];
        }
            break;
        default:
            break;
    }
    return nil;
    
}
+ (PeriodStatusModel *) getPeriodModel:(ScheduleModel*) model withRow:(NSInteger)row{

    switch (row) {
        case 0:
            return model.wakePeriod;
            break;
        case 1:
            return model.leavePeriod;
            break;
        case 2:
            return model.returnPeriod;
            break;
        case 3:
            return model.sleepPeriod;
            break;
        default:
            break;
    }
    return nil;
}

+ (CWSFanType)tableFan:(NSInteger)row
{
    CWSFanType type = CWSFanType_Auto;
    
    switch (row) {
        case 1:
            type = CWSSystemType_On;
            break;
        case 2:
            type = CWSFanType_Auto;
            break;
        case 3:
            type = CWSSystemType_Circulate;
            break;
        default:
            type = CWSFanType_Auto;
            break;
    }
    return type;
}
+ (CWSSystemType) tableSystem:(NSInteger)row
{
    CWSSystemType type = CWSSystemType_Auto;
    
    switch (row) {
        case 1:
            type = CWSSystemType_Cool;
            break;
        case 2:
            type = CWSSystemType_Off;
            break;
        case 3:
            type = CWSSystemType_Heat;
            break;
        case 4:
            type = CWSSystemType_Auto;
            break;
        default:
            type = CWSSystemType_Auto;
            break;
    }
    return type;
}
@end
