//
//  OKSerServer.m
//  cws
//
//  Created by soeasyright on 2015/11/25.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "OKSerServer.h"

#import "HeaderCell.h"
#import "LGAlertView.h"
#import "Location.h"
#import "Thermostats.h"
#import <Motis/Motis.h>
#import <AFNetworking/AFNetworking.h>
@interface OKSerServer()
@end
@implementation OKSerServer

#pragma mark - Singleton

+(instancetype)sharedInstance {
    
    static dispatch_once_t onceToken;
    static OKSerServer *sharedInstance = nil;
    
    dispatch_once(&onceToken, ^{
        sharedInstance = [[OKSerServer alloc] init];
        sharedInstance.choseLocation = -1;
        sharedInstance.choseThermostats = -1;
        [sharedInstance setNotification];
    });
    return sharedInstance;
}

- (void) setNotification{
    [OKSerNetwork sharedInstance];
}
- (void)reloadThermostatsData
{
    BOOL isNeedReloadtable = NO;
    BOOL isNeedReloadDB = NO;
    for (Location * location in self.location) {
        NSInteger count = 0;
        for (Thermostats * thermostats in location.thermostats) {
            if (thermostats.show == 1) {
                count++;
                isNeedReloadDB= YES;
            }
        }
        if (location.thermostatsNum !=count) {
            isNeedReloadtable = YES;
            location.thermostatsNum = count;
        }

    }
    if (isNeedReloadtable) {
        [[NSNotificationCenter defaultCenter] postNotificationName:@"NeedRefreshForThermostatsNum" object:nil];
    }
    if (isNeedReloadDB) {
        [self loadThermostatsDataFromDB];
    }
    
    
}
- (void) setForFirstTimeLaunch{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    if ([userDefaults boolForKey:OKSerFristTimeLaunch] == NO) {
        Location *locaiotn = [Location MR_createEntity];
        locaiotn.displayName = @"My home";
        locaiotn.index = 0;
        [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
        
        [userDefaults setBool:YES forKey:OKSerFristTimeLaunch];
        [userDefaults setObject:@0 forKey:CWSTotalLocationCount];
        [userDefaults synchronize];
    }

}

- (void) loadLocationDataFromDB{
    [self setForFirstTimeLaunch];
    
    self.location = [Location MR_findAllSortedBy:@"index" ascending:YES];
}

- (void) loadAllData{
    

    NSArray *all = [Thermostats MR_findAll] ;
    for (Thermostats *t in all) {
        //init
        t.isReadConfigure = NO;
        t.isReadStatus = NO;
        t.show = 0;
        t.chosePeriod = 0;
        
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        NSString *url =[NSString stringWithFormat:@"%@/thermostat_cfg.js",t.ip];
        [manager GET:url
          parameters:nil
             success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
                 NSString *tmp = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
                 NSArray *tmp2 = [tmp componentsSeparatedByString:@"="];
                 NSArray *tmp3 =[tmp2[1] componentsSeparatedByString:@";"];
                 NSData *objectData = [tmp3[0] dataUsingEncoding:NSUTF8StringEncoding];
                 NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                      options:NSJSONReadingMutableContainers
                                                                        error:nil];
                 NSLog(@"thermostat_cfg.js %@",json);
                 t.nSystem =        [json[@"__SL_P_SST"] integerValue];
                 t.nTemporaryHeat = [json[@"__SL_P_TTH"] integerValue];
                 t.nTemporaryCold = [json[@"__SL_P_TTL"] integerValue];
                 t.nPermanentHeat = [json[@"__SL_P_PTH"] integerValue];
                 t.nPermanentCold = [json[@"__SL_P_PTL"] integerValue];
                 t.nWeekType =      [json[@"__SL_P_PGO"] integerValue];
                 t.nWeekStatus =    [json[@"__SL_P_PGO"] integerValue];
                 t.nHoldMin =       [json[@"__SL_P_HOS"] integerValue];
                 t.nFan =           [json[@"__SL_P_FST"] integerValue];
                 t.nOperation =     [json[@"__SL_P_OPE"] integerValue];
                 [t setSchedule:     json[@"__SL_P_SC1"] forIndex:0];
                 [t setSchedule:     json[@"__SL_P_SC2"] forIndex:1];
                 
                 
                 t.isReadConfigure = YES;
                 if (t.isReadConfigure && t.isReadStatus) {
                     t.show = 1;
                     t.backupThermostats = [t createBackup];
                     [self reloadThermostatsData];
                 }
             } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
                 NSLog(@"get data by URL error: %@", [error localizedDescription]);
             }];
        NSString *url2 =[NSString stringWithFormat:@"%@/thermostat_status.js",t.ip];
        [manager GET:url2
          parameters:nil
             success:^(AFHTTPRequestOperation * _Nonnull operation, id  _Nonnull responseObject) {
                 NSString *tmp = [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding];
                 NSArray *tmp2 = [tmp componentsSeparatedByString:@"="];
                 NSArray *tmp3 =[tmp2[1] componentsSeparatedByString:@";"];
                 NSData *objectData = [tmp3[0] dataUsingEncoding:NSUTF8StringEncoding];
                 NSDictionary *json = [NSJSONSerialization JSONObjectWithData:objectData
                                                                      options:NSJSONReadingMutableContainers
                                                                        error:nil];
                 NSLog(@"thermostat_status.js %@",json);
                 t.nDegree =     json[@"__SL_P_C_T"];
                 t.nHumidity =   json[@"__SL_P_C_H"];
                 
                 t.isReadStatus = YES;
                 if (t.isReadConfigure && t.isReadStatus) {
                     t.show = 1;
                     t.backupThermostats = [t createBackup];
                     [self reloadThermostatsData];
                 }
             } failure:^(AFHTTPRequestOperation * _Nullable operation, NSError * _Nonnull error) {
                 NSLog(@"get data by URL error: %@", [error localizedDescription]);
             }];
        
    }
}
- (void) loadThermostatsDataFromDB
{
    if (self.choseLocation == -1) {
        return;
    }
    Location *location = [self.location objectAtIndex:self.choseLocation];
    NSArray *tmp = [location.thermostats allObjects];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"show == 1"];
    self.thermostats = [tmp filteredArrayUsingPredicate: predicate];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NeedRefreshForDisplayThermostats" object:nil];

}

- (BOOL) addNewThermostatWithSSID:(NSString *)ssid andPassword:(NSString *)password
{
    BOOL addNew = NO;
    Location *location = [self.location objectAtIndex:self.choseLocation];
    SmartConfigGlobalConfig *globalConfig = [SmartConfigGlobalConfig getInstance];
    NSMutableDictionary *devices = [globalConfig getDevices];
    
    for(id key in devices) {
        NSLog(@"key %@ ",key);
        NSArray *find =  [Thermostats MR_findByAttribute:@"macAdress" withValue:key];
        NSMutableDictionary *device = [devices objectForKey:key];
        if (find.count == 0) {
            //new
            
            Thermostats *thermostats = [Thermostats MR_createEntity];
            thermostats.macAdress = [device objectForKey:@"name"];
            thermostats.ip = [device objectForKey:@"url"];
            thermostats.displayName = @"Default Name";
            thermostats.wifiName = ssid;
            thermostats.wifiPassword = password;
            [location addThermostatsObject:thermostats];
            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
            addNew = YES;
        }
        
    }
    if (addNew) {
        [self loadAllData];
    }
    return addNew;
}


- (void) setChoseLocation:(NSInteger) row
{
    if (row == -1) {
        return;
    }
    _choseLocation = row;
    _thermostats = nil;
    [self loadAllData];
}

- (BOOL) isNeedSumbitForSetThermostatValue:(NSDictionary *) dict
{
    [dict enumerateKeysAndObjectsUsingBlock:^(NSString *key, id obj, BOOL *stop) {
        if ([_singleThermostat respondsToSelector:NSSelectorFromString(key)]) {
            [_singleThermostat setValue:obj forKey:key];   
        }
    }];
    _isNeedSubmit = ![_singleThermostat isSameThermostats];
    return _isNeedSubmit;
}
- (BOOL)isNeedSumbitForSetPeriodValueByDict:(NSDictionary *) dict{
    [dict enumerateKeysAndObjectsUsingBlock:^(NSString *key, id obj, BOOL *stop) {
        PeriodStatusModel *psm = [CWSUtil getPeriodModel:_singleThermostat AtRow:_singleThermostat.chosePeriod];
        if (psm) {
            [self setPeriod:psm setValue:obj forKey:key];
        }
    }];
    _isNeedSubmit = ![_singleThermostat isSameThermostats];
    return _isNeedSubmit;
}

- (void)setPeriod:(PeriodStatusModel*)model setValue:(id)value forKey:(NSString *)key{
    if ([model respondsToSelector:NSSelectorFromString(key)]) {
        [model setValue:value forKey:key];
    }
}

- (void) saveDataToThermostats
{
 
    _singleThermostat.backupThermostats = [_singleThermostat createBackup];


    NSString *url =[NSString stringWithFormat:@"%@/No_content",_singleThermostat.ip];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init] ;
    [request setURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setTimeoutInterval:10.0];
    NSMutableString *para=[[NSMutableString alloc] init];
    [para appendFormat:@"__SL_P_SST=%ld&", (long)_singleThermostat.nSystem];
    [para appendFormat:@"__SL_P_PTH=%ld&", (long)_singleThermostat.nPermanentHeat];
    [para appendFormat:@"__SL_P_PTL=%ld&", (long)_singleThermostat.nPermanentCold];
    [para appendFormat:@"__SL_P_TTH=%ld&", (long)_singleThermostat.nTemporaryHeat];
    [para appendFormat:@"__SL_P_TTL=%ld&", (long)_singleThermostat.nTemporaryCold];
    [para appendFormat:@"__SL_P_HOS=%ld&", (long)_singleThermostat.nHoldMin];
    [para appendFormat:@"__SL_P_FST=%ld&", (long)_singleThermostat.nFan];
    [para appendFormat:@"__SL_P_OPE=%ld&", (long)_singleThermostat.nOperation];
    [para appendFormat:@"__SL_P_PGO=%ld&", (long)_singleThermostat.nWeekType];
    [para appendFormat:@"__SL_P_TEC=TEC&"];
    [para appendFormat:@"__SL_P_SC1=%@&",_singleThermostat.sSc1];
    [para appendFormat:@"__SL_P_SC2=%@&",_singleThermostat.sSc2];
    [para appendFormat:@"__SL_P_SCH=SCH"];

    [request setHTTPBody:[para dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError)
     {
         NSLog(@"%@",response);
         
     }];

    _isNeedSubmit = NO;
    
}



- (void) showAlertWithBackButtonOnViewConrtoller:(UIViewController<OKSerServerDelege> *)viewcontroller{
    _isNeedSubmit = NO;
    [[[LGAlertView alloc] initWithTitle:@"Change Settings"
                                message:@"Did you submit the changes?"
                                  style:LGAlertViewStyleAlert
                           buttonTitles:@[@"Yes"]
                      cancelButtonTitle:@"No"
                 destructiveButtonTitle:nil
                          actionHandler:^(LGAlertView *alertView, NSString *title, NSUInteger index) {
                              [self saveDataToThermostats];
                              [viewcontroller onBackButton:nil];
                          }
                          cancelHandler:^(LGAlertView *alertView) {
                            [_singleThermostat cancelChange];
                            [viewcontroller onBackButton:nil];
                          }
                     destructiveHandler:nil] showAnimated:YES completionHandler:nil];
}
- (void) showAlertWithIndex:(NSInteger)index onTabBarConrtoller:(UITabBarController *)tabbarcontroller{
    _isNeedSubmit = NO;
    [[[LGAlertView alloc] initWithTitle:@"Change Settings"
                                message:@"Did you submit the changes?"
                                  style:LGAlertViewStyleAlert
                           buttonTitles:@[@"Yes"]
                      cancelButtonTitle:@"No"
                 destructiveButtonTitle:nil
                          actionHandler:^(LGAlertView *alertView, NSString *title, NSUInteger i) {
                              [self saveDataToThermostats];
                              [tabbarcontroller setSelectedIndex:index];
                          }
                          cancelHandler:^(LGAlertView *alertView) {
                              [_singleThermostat cancelChange];
                              [tabbarcontroller setSelectedIndex:index];
                          }
                     destructiveHandler:nil] showAnimated:YES completionHandler:nil];

}



+ (NSArray*) classTable:(Class)viewClass{
    static dispatch_once_t onceToken;
    static NSDictionary *classTable = nil;
    dispatch_once(&onceToken, ^{
        classTable = @{
                  @"ThermostatTabViewController":@[
                          @[[ModeCell class]],
                          @[[TitleCell class],[TemperatureCell class]]
                          ],
                  @"SystemAndFanTabViewController":@[
                          @[[TitleCell class],[RadioCell class],[RadioCell class],[RadioCell class],[RadioCell class]],
                          @[[TitleCell class],[RadioCell class],[RadioCell class],[RadioCell class]]
                          ],
                  @"ScheduleTabViewController":@[
                          @[[WeekCell class]],
                          @[[ScheduleCell class],[ScheduleCell class],[ScheduleCell class],[ScheduleCell class]],
                          @[[NextSettingCell class]]
                          ],
                  @"PeriodTabViewController":@[
                          @[[WeekCell class]],
                          @[[TitleCell class],[SetTimeCell class]],
                          @[[TitleCell class],[TemperatureCell class]]
                          ]
                  };
        
    });
    return classTable[NSStringFromClass(viewClass)];
}
+ (Class) getClassFromViewClass:(Class)viewClass atIndex:(NSIndexPath*) index
{
    return [OKSerServer classTable:viewClass][index.section][index.row];
}
+ (NSInteger) getSectionFromViewClass:(Class)viewClass{
    return [[OKSerServer classTable:viewClass] count];
}
+ (NSInteger) getSectionFromViewClass:(Class)viewClass numberOfRowsInSection:(NSInteger)section{
    return [[OKSerServer classTable:viewClass][section] count];
}
+ (NSString *) getInfoFromViewClass:(Class)viewClass atIndex:(NSIndexPath*) index
{
    static dispatch_once_t onceToken;
    static NSDictionary *defaultInfoTable = nil;
    
    dispatch_once(&onceToken, ^{
        defaultInfoTable = @{
                             
                             @"ThermostatTabViewController":@[
                                     @[@"",@""],
                                     @[@"Temperature",@""]
                                     ],
                             @"SystemAndFanTabViewController":@[
                                     @[@"System",@"COOL",@"OFF",@"HEAT",@"AUTO H/C"],
                                     @[@"Fan",@"FAN ON",@"FAN AUTO",@"FAN AUTO & CIRCULATE"]
                                     ],
                             
                             @"ScheduleTabViewController":@[
                                     @[@""],
                                     @[@"Wake",@"Leave",@"Return",@"Sleep"],
                                     @[@""]
                                     ],
                             @"PeriodTabViewController":@[
                                    @[@"",@"When do you want to wake up?",@"What setting do you perfer when you wake up?"],
                                    @[@"",@"When do you leave?",@"What setting do you perfer when you leave?"],
                                    @[@"",@"When do you return?",@"What setting do you perfer when you return?"],
                                    @[@"",@"When do you want to sleep?",@"What setting do you perfer when you sleep?"],
                                     ],

                       };
        
        
    });
    return defaultInfoTable[NSStringFromClass(viewClass)][index.section][index.row];
}

+ (NSString *) getPeriodNameAtRow:(NSInteger) index
{
    static dispatch_once_t onceToken;
    static NSArray *defaultTable = nil;
    dispatch_once(&onceToken, ^{
        defaultTable = @[@"Wake Setting",@"Leave Setting",@"Return Setting",@"Sleep Setting"];
    });
    return index <4 && index >-1 ? [defaultTable objectAtIndex:index] : @"";
}



@end
