//
//  OKSerNetwork.h
//  cws
//
//  Created by soeasyright on 2015/11/30.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SmartConfigDiscoverMDNS.h"
#import "SmartConfigGlobalConfig.h"
#import "Reachability.h"
#import "FirstTimeConfig.h"
@interface OKSerNetwork : NSObject
@property (nonatomic, retain) SmartConfigGlobalConfig *globalConfig;
@property (nonatomic, strong) SmartConfigDiscoverMDNS *mdnsService;
@property (nonatomic, retain) Reachability *wifiReachability;
@property ( nonatomic) FirstTimeConfig *firstTimeConfig;

+ (instancetype)sharedInstance;
- (void)startActionWithSSID:(NSString *)ssid andPassword:(NSString *)password;
@end
