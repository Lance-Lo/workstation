//
//  CWSUtil.h
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>

#define OKSerServerReloadTableNotification @"OKSerServerReloadTableNotification"
#define OKSerFristTimeLaunch @"OKSerFristTimeLaunch"
#define CWSTotalLocationCount @"CWSTotalLocationCount"
typedef NS_ENUM(NSInteger, CWSSystemType) {
    CWSSystemType_Off = 0,
    CWSSystemType_Cool = 1,
    CWSSystemType_Heat = 2,
    CWSSystemType_Auto = 3,
};

typedef NS_ENUM(NSInteger, CWSFanType) {
    CWSFanType_Auto = 0,
    CWSSystemType_On = 1,
    CWSSystemType_Circulate = 2,
};

typedef NS_ENUM(NSInteger, CWSOperationType) {
    CWSOperationType_Hold = 0,
    CWSOperationType_Schedule = 1,
    
};

typedef NS_ENUM(NSInteger, CWSProgramOptionsType) {
    CWSProgramOptionsType_5_2 = 0,
    CWSProgramOptionsType_6_1 = 1,
    CWSProgramOptionsType_7 = 2,
    
};

typedef NS_ENUM(NSInteger, CWSWeekCellStatus) {
    CWSWeekCellStatus_5_2_now_5,
    CWSWeekCellStatus_6_1_now_6,
    CWSWeekCellStatus_7_now_7,
    CWSWeekCellStatus_5_2_now_2,
    CWSWeekCellStatus_6_1_now_1,
};

typedef NS_ENUM(NSInteger, CWSBackupAction) {
    CWSBackupAction_Tab_1 = 0,
    CWSBackupAction_Tab_2 = 1,
    CWSBackupAction_Tab_3 = 2,
    CWSBackupAction_Back = 3,
};


@class PeriodStatusModel;
@interface CWSUtil : NSObject
+ (PeriodStatusModel *) getPeriodModel:(NSObject *) mModel AtRow:(NSInteger )row;
+ (CWSFanType)tableFan:(NSInteger)row;
+ (CWSSystemType)tableSystem:(NSInteger)row;
@end
