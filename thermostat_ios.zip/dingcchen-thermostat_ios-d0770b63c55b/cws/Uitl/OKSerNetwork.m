//
//  OKSerNetwork.m
//  cws
//
//  Created by soeasyright on 2015/11/30.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "OKSerNetwork.h"
#import <SystemConfiguration/CaptiveNetwork.h>
#import "LGAlertView.h"
int const discoveryTimeout = 60;
int const MDNSRestartTime = 15;
@interface OKSerNetwork()
@property (nonatomic) BOOL discoveryInProgress;
@property (weak, nonatomic) NSTimer *discoveryTimer;
@property (weak, nonatomic) NSTimer *mdnsTimer;
@property (retain) NSTimer *updateTimer;
@property (copy, atomic) NSString *passwordKey;
@property (copy, atomic) NSString *ssid;
@property (retain, atomic) NSData *freeData;
@property int progressTime;
@property BOOL alertOpen;
@property (strong, nonatomic) LGAlertView *searchAlertView;

@end
@implementation OKSerNetwork

+(instancetype)sharedInstance {
    
    static dispatch_once_t onceToken;
    static OKSerNetwork *sharedInstance = nil;
    
    dispatch_once(&onceToken, ^{
        sharedInstance = [[OKSerNetwork alloc] init];
        sharedInstance.globalConfig = [SmartConfigGlobalConfig getInstance];
        sharedInstance.globalConfig.launchTime = [NSDate date];
        [sharedInstance detectWifi];
        
        // start mdns refresh when loading application
        sharedInstance.mdnsService = [SmartConfigDiscoverMDNS getInstance];
        [sharedInstance.mdnsService emptyMDNSList];
        [sharedInstance.mdnsService startMDNSDiscovery:@""];
       
    });
    return sharedInstance;
}

- (void)detectWifi
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(wifiStatusChanged:)
                                                 name:kReachabilityChangedNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(deviceAdded:)
                                                 name:@"deviceFound"
                                               object:nil];
    self.wifiReachability = [Reachability reachabilityForLocalWiFi];
    [self.wifiReachability connectionRequired];
    [self.wifiReachability startNotifier];
    /// retain is just for safety
    
    NetworkStatus netStatus = [self.wifiReachability currentReachabilityStatus];
//    NSLog(@"Net Status: %d", netStatus);
    
    // show or hide main view
    [self checkWifiReachibility:netStatus];
    [self updateNetworkName];
    
    self.updateTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(updateNetworkName) userInfo:nil repeats:YES];
    
}

/*
 Notification method handler when status of wifi changes
 @param the fired notification object
 */
- (void)wifiStatusChanged:(NSNotification *)notification{
    
//    NSLog(@"%s", __func__);
//    NSLog(@"%@", notification);
    Reachability *verifyConnection = [notification object];
    NSAssert(verifyConnection != NULL, @"currentNetworkStatus called with NULL verifyConnection Object");
    NetworkStatus netStatus = [verifyConnection currentReachabilityStatus];
//    NSLog(@"New net Status: %d", netStatus);
    
    // show or hide main view
    [self checkWifiReachibility:netStatus];
    [self updateNetworkName];
    
    // NSLog(@"ssid %@, gatewayAddress %@", [[Reachability alloc] , [FirstTimeConfig getGatewayAddress]);
    // [wifiReachability stopNotifier];
    // [wifiReachability performSelector:@selector(startNotifier) withObject:nil afterDelay:3.0];
    
}

- (void) checkWifiReachibility:(int)netStatus
{
    if ( netStatus != ReachableViaWiFi  ) { // No activity if no wifi
//        NSLog(@"No Wifi");
//        [self alertWithTitle:@"No WiFi detected" andMessage:@"Please turn on wifi"];
    }
}

- (void)updateNetworkName
{
    id ssidInfo = [self fetchSSIDInfo];
    id ssidName = [ssidInfo objectForKey:@"SSID"];
    if(![self.globalConfig.ssidName isEqual:ssidName])
    {
        self.globalConfig.ssidName = ssidName;
//        NSLog(@"Setting new SSID Name: %@", self.globalConfig.ssidName);
    }
}

- (id)fetchSSIDInfo {
    NSArray *ifs = (__bridge_transfer id)CNCopySupportedInterfaces();
    //    NSLog(@"Supported interfaces: %@", ifs);
    id info = nil;
    for (NSString *ifnam in ifs) {
        info = (__bridge_transfer id)CNCopyCurrentNetworkInfo((__bridge CFStringRef)ifnam);
        //        NSLog(@"%@ => %@", ifnam, info);
        if (info && [info count]) { break; }
    }
    //  NSLog(@"Network info: %@", info);
    return info;
}



/*!!!!!!
 This is the button action, where we need to start or stop the request
 @param: button ... tag value defines the action !!!!!!!!!
 !!!*/
- (void)startActionWithSSID:(NSString *)ssid andPassword:(NSString *)password
{
    
    // detect if we have wifi reachability
    NetworkStatus netStatus = [self.wifiReachability currentReachabilityStatus];
    _passwordKey = password;
    _ssid = ssid;
    if ( netStatus != ReachableViaWiFi )
    { // No activity if no wifi
        [self alertWithTitle:@"No WiFi detected" andMessage:@"Please turn on wifi"];
    }
    else
    {
        [self continueStartAction];
    }
    
}


- (void) continueStartAction{
    
    BOOL isAdd=[[OKSerServer sharedInstance] addNewThermostatWithSSID:self.ssid andPassword:self.passwordKey];
    NSLog(isAdd ? @"isAdd yes ": @"isAdd no");
    if (isAdd) {
        [self alertWithTitle:@"Success" andMessage:@"A new device was discovered!"];
        return;
    }
    
    
    self.discoveryInProgress = YES;
    self.progressTime = 0;
    self.discoveryTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(updateProgress) userInfo:nil repeats:YES];
    _searchAlertView = [[LGAlertView alloc] initWithActivityIndicatorAndTitle:@"Searching"
                                                                      message:@"Waiting please"
                                                                        style:LGAlertViewStyleAlert
                                                                 buttonTitles:nil
                                                            cancelButtonTitle:@"Cancel Searching..."
                                                       destructiveButtonTitle:nil
                                                                actionHandler:nil
                                                                cancelHandler:^(LGAlertView *alertView) {
                                                                    [self cancelAction];
                                                                }
                                                           destructiveHandler:nil];
    [_searchAlertView showAnimated:YES completionHandler:nil];
    [self startTransmitting];
    // start discovery using TI lib
}

/**
 This is the cancel action
 
 */
- (void)cancelAction{
    [self stopDiscovery];
}


/*
 This method start the transmitting the data to connected
 AP. Nerwork validation is also done here. All exceptions from
 library is handled.
 */
- (void)startTransmitting{
    @try {
        [self connectLibrary];
        if (self.firstTimeConfig == nil) {
            return;
        }
        [self sendAction];
    }
    @catch (NSException *exception) {
        NSLog(@"%s exception == %@",__FUNCTION__,[exception description]);
    }
    @finally {
    }
}

/*
 This method begins configuration transmit
 In case of a failure the method throws an OSFailureException.
 */
-(void) sendAction{
    @try {
//        NSLog(@"%s begin", __PRETTY_FUNCTION__);
        [self.firstTimeConfig transmitSettings];
//        NSLog(@"%s end", __PRETTY_FUNCTION__);
    }
    @catch (NSException *exception) {
        NSLog(@"exception === %@",[exception description]);
    }
    @finally {
        
    }
}
-(void)updateProgress {
    self.progressTime ++;
    if(self.progressTime >= discoveryTimeout) {
        [self discoveryTimedOut];
    }
    
}

/* timeout discovery */
-(void) discoveryTimedOut {
    [self stopDiscovery];
    [_searchAlertView dismissAnimated:YES completionHandler:nil];
    [self alertWithTitle:@"Sorry!" andMessage:@"Can not FIND any thermostat!"];
    
}

-(void) stopDiscovery {
    [self.mdnsTimer invalidate];
    self.discoveryInProgress = NO;
    //    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    [self.firstTimeConfig stopTransmitting];
    [self.discoveryTimer invalidate];
    [self mDnsDiscoverStop];
    
    
}

// check for internet and initiate the libary object for further transmit.
-(void) connectLibrary
{
    @try {
        [self disconnectFromLibrary];
//        self.passwordKey = [self.apPass.text length] ? self.apPass.text : nil;
        self.freeData = [NSData alloc];
        self.freeData = [@"" dataUsingEncoding:NSUTF8StringEncoding];
        
        
        //        self.debugField.text = [[NSString alloc] initWithData:freeData encoding:NSUTF8StringEncoding];
        NSString *ipAddress = [FirstTimeConfig getGatewayAddress];
        self.firstTimeConfig = [[FirstTimeConfig alloc] initWithData:ipAddress withSSID:self.ssid withKey:self.
                                passwordKey withFreeData:self.freeData withEncryptionKey:Nil numberOfSetups:4 numberOfSyncs:10 syncLength1:3 syncLength2:23 delayInMicroSeconds:1000];
        
        [self mDnsDiscoverStart];
        // set timer to fire mDNS after 15 seconds
        self.mdnsTimer = [NSTimer scheduledTimerWithTimeInterval:MDNSRestartTime target:self selector:@selector(mDnsDiscoverStart) userInfo:nil repeats:NO];
        
        
        
    }
    @catch (NSException *exception) {
        NSLog(@"%s exception == %@",__FUNCTION__,[exception description]);
    }
    
}
-(void) alertWithTitle: (NSString *) title andMessage:(NSString *)message
{
    [[[LGAlertView alloc] initWithTitle:title
                                message:message
                                  style:LGAlertViewStyleAlert
                           buttonTitles:nil
                      cancelButtonTitle:@"OK"
                 destructiveButtonTitle:nil
                          actionHandler:nil
                          cancelHandler:nil
                     destructiveHandler:nil] showAnimated:YES completionHandler:nil];

}
- (void) mDnsDiscoverStart {
    [self.mdnsService startMDNSDiscovery:@""];
}

- (void) mDnsDiscoverStop {
    [self.mdnsService stopMDNSDiscovery];
    
}

// disconnect libary method involves to release the existing object and assign nil.
-(void) disconnectFromLibrary
{
    self.firstTimeConfig = nil;
}
-(void)deviceAdded:(id)sender
{
    if(self.discoveryInProgress == YES)
    {
        [self stopDiscovery];
        [_searchAlertView dismissAnimated:YES completionHandler:nil];
        [[OKSerServer sharedInstance] addNewThermostatWithSSID:self.ssid andPassword:self.passwordKey];        
        [self alertWithTitle:@"Success" andMessage:@"A new device was discovered!"];
    }
}


@end
