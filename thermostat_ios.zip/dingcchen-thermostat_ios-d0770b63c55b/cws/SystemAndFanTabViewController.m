//
//  SystemAndFanTabViewController.m
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "SystemAndFanTabViewController.h"
#import "HeaderCell.h"
@interface SystemAndFanTabViewController ()<OKSerCellDelege,OKSerServerDelege>
@end

@implementation SystemAndFanTabViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[TitleCell nib] forCellReuseIdentifier:[TitleCell Identifier]];
    [self.tableView registerNib:[RadioCell nib] forCellReuseIdentifier:[RadioCell Identifier]];
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedRightButton:)];
    [swipeLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
    [self.view addGestureRecognizer:swipeLeft];
    
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedLeftButton:)];
    [swipeRight setDirection:UISwipeGestureRecognizerDirectionRight];
    [self.view addGestureRecognizer:swipeRight];
}
- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.navigationItem.title = [OKSerServer sharedInstance].singleThermostat.displayName;
    [self showSumitButton:NO];
    [self.tableView reloadData];
    [self.tabBarController.navigationItem setLeftBarButtonItem:[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_back"] landscapeImagePhone:nil style:UIBarButtonItemStyleDone target:self action:@selector(onBackButton:)]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)tappedRightButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    [self.tabBarController setSelectedIndex:selectedIndex + 1];
//    CATransition *anim= [CATransition animation];
//    [anim setType:kCATransitionPush];
//    [anim setSubtype:kCATransitionFromRight];
//    [anim setDuration:0.25];
//    [anim setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
//
//    [self.tabBarController.view.layer addAnimation:anim forKey:@"fadeTransition"];
}

- (IBAction)tappedLeftButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    
    [self.tabBarController setSelectedIndex:selectedIndex - 1];
//    CATransition *anim= [CATransition animation];
//    [anim setType:kCATransitionPush];
//    [anim setSubtype:kCATransitionFromLeft];
//    
//    [anim setDuration:0.25];
//    [anim setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
//
//    [self.tabBarController.view.layer addAnimation:anim forKey:@"fadeTransition"];
}
#pragma mark - <UITableViewDataSource>

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [OKSerServer getSectionFromViewClass:[self class]];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [OKSerServer getSectionFromViewClass:[self class] numberOfRowsInSection:section];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    OKSerTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:[[OKSerServer getClassFromViewClass:[self class] atIndex:indexPath ] Identifier] forIndexPath:indexPath];
    [cell setCellInfo:[OKSerServer getInfoFromViewClass:[self class] atIndex:indexPath]];
    [cell setCellView:[OKSerServer sharedInstance].singleThermostat AtIndexPath:indexPath];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row!=0) {
        if (indexPath.section == 0) {
            [self refreshData:@{@"nSystem":@([CWSUtil tableSystem:indexPath.row])}];
        }
        if (indexPath.section == 1) {
            [self refreshData:@{@"nFan":@( [CWSUtil tableFan:indexPath.row])}];
        }
    }
    [self.tableView reloadData];
    
    
}
#pragma mark - <UITableViewDelegate>
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [[OKSerServer getClassFromViewClass:[self class] atIndex:indexPath ] heightCell];
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    NSOperatingSystemVersion tmp = [[NSProcessInfo processInfo] operatingSystemVersion];
    return tmp.majorVersion == 8 && tmp.minorVersion ==1 && section == 0 ? 60.: 0.;
}
#pragma mark - onButtonClicked
- (void)onBackButton:(id)sender{
    if ([OKSerServer sharedInstance].isNeedSubmit) {
        [self showSumitButton:NO];
        [[OKSerServer sharedInstance] showAlertWithBackButtonOnViewConrtoller:self];
        return;
    }
    [self.tabBarController.navigationController popViewControllerAnimated:YES];
}
- (void)refreshData:(NSDictionary*) dict{
    [self showSumitButton:[[OKSerServer sharedInstance] isNeedSumbitForSetThermostatValue:dict]];
}
- (void) showSumitButton:(BOOL)show{
    if (show) {
        if (![self.tabBarController.navigationItem rightBarButtonItem]) {
            [self.tabBarController.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_ok"] landscapeImagePhone:nil style:UIBarButtonItemStyleDone target:self action:@selector(onRightButton:) ] animated:YES];
        }
    }
    else
    {
        [self.tabBarController.navigationItem setRightBarButtonItem:nil];
    }
    
}
-(void)onRightButton:(id)sender{
    [[OKSerServer sharedInstance] saveDataToThermostats];
    [self showSumitButton:NO];
}


@end
