//
//  ThermostatTabViewController.m
//  cws
//
//  Created by soeasyright on 2015/11/22.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "ThermostatTabViewController.h"
#import "HeaderCell.h"

@interface ThermostatTabViewController ()<OKSerCellDelege,UITabBarControllerDelegate,OKSerServerDelege>
@property (nonatomic,assign) BOOL isShowSumbit;

@end

@implementation ThermostatTabViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerNib:[TemperatureCell nib] forCellReuseIdentifier:[TemperatureCell Identifier]];
    [self.tableView registerNib:[ModeCell nib] forCellReuseIdentifier:[ModeCell Identifier]];
    [self.tableView registerNib:[TitleCell nib] forCellReuseIdentifier:[TitleCell Identifier]];
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedRightButton:)];
    [swipeLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
    [self.view addGestureRecognizer:swipeLeft];
    
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedLeftButton:)];
    [swipeRight setDirection:UISwipeGestureRecognizerDirectionRight];
    [self.view addGestureRecognizer:swipeRight];
}
- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.navigationItem.title = [OKSerServer sharedInstance].singleThermostat.displayName;
    [self showSumitButton:NO];
    [OKSerServer sharedInstance].singleThermostat.isShowPeriod = NO;
    [self.tableView reloadData];
    self.tabBarController.delegate = self;
    self.navigationItem.hidesBackButton = YES;
    [self.tabBarController.navigationItem setLeftBarButtonItem:[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_back"] landscapeImagePhone:nil style:UIBarButtonItemStyleDone target:self action:@selector(onBackButton:)]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)tappedRightButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    [self.tabBarController setSelectedIndex:selectedIndex + 1];
//    CATransition *anim= [CATransition animation];
//    [anim setType:kCATransitionPush];
//    [anim setSubtype:kCATransitionFromRight];
//    [anim setDuration:0.25];
//    [anim setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
//    [self.tabBarController.view.layer addAnimation:anim forKey:@"switchView"];
}

- (IBAction)tappedLeftButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    
    [self.tabBarController setSelectedIndex:selectedIndex - 1];
//    CATransition *anim= [CATransition animation];
//    [anim setType:kCATransitionFade];
//    [anim setSubtype:kCATransitionFromLeft];
//    
//    [anim setDuration:0.25];
//    [anim setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear]];
//    [self.tabBarController.view.layer addAnimation:anim forKey:@"switchView"];
}
#pragma mark - <UITableViewDataSource>


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [OKSerServer getSectionFromViewClass:[self class]];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [OKSerServer getSectionFromViewClass:[self class] numberOfRowsInSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    OKSerTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:[[OKSerServer getClassFromViewClass:[self class] atIndex:indexPath ] Identifier] forIndexPath:indexPath];
    if ([cell class] == [TitleCell class]) {
        [cell setCellInfo:[OKSerServer getInfoFromViewClass:[self class] atIndex:indexPath]];
        if (indexPath.section == 1 ) {
            if ([OKSerServer sharedInstance].singleThermostat.nOperation == CWSOperationType_Schedule ) {
                [cell setCellInfo:@"Temporary Hold Temperature"];
            }
            else{
                [cell setCellInfo:@"Permanent Hold Temperature"];
            }

        }
    }
    [cell setCellView:[OKSerServer sharedInstance].singleThermostat ];
    cell.delegte = self;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}
#pragma mark - <UITableViewDelegate>
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section ==0 && [OKSerServer sharedInstance].singleThermostat.nOperation == CWSOperationType_Hold )
    {
        return 70.;
    }
    return [[OKSerServer getClassFromViewClass:[self class] atIndex:indexPath ] heightCell];
}
#pragma mark - onButtonClicked
- (void)onBackButton:(id)sender{
    if ([OKSerServer sharedInstance].isNeedSubmit) {
        [self showSumitButton:NO];
        [[OKSerServer sharedInstance] showAlertWithBackButtonOnViewConrtoller:self];
        return;
    }
    [self.tabBarController.navigationController popViewControllerAnimated:YES];
}

- (void)refreshData:(NSDictionary*) dict{
    [self showSumitButton:[[OKSerServer sharedInstance] isNeedSumbitForSetThermostatValue:dict]];
    [self.tableView reloadData];
}
- (void) showSumitButton:(BOOL)show{
    if (show) {
        //avoid repeat create
        if (![self.tabBarController.navigationItem rightBarButtonItem]) {
        [self.tabBarController.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_ok"] landscapeImagePhone:nil style:UIBarButtonItemStyleDone target:self action:@selector(onRightButton:) ] animated:YES];
        }
    }
    else
    {
        [self.tabBarController.navigationItem setRightBarButtonItem:nil animated:YES];
    }
    
}
-(void)onRightButton:(id)sender{
    [[OKSerServer sharedInstance] saveDataToThermostats];
    [self showSumitButton:NO];
    
}
#pragma UITabBarControllerDelegate
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController
{
    if ([OKSerServer sharedInstance].isNeedSubmit) {
        [self.tabBarController.navigationItem setRightBarButtonItem:nil animated:YES];
        NSInteger tab = [tabBarController.viewControllers indexOfObject:viewController];
        [[OKSerServer sharedInstance] showAlertWithIndex:tab onTabBarConrtoller:tabBarController];
        return NO;
    }
    return YES;
}


@end
