//
//  PeriodTabViewController.m
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "PeriodTabViewController.h"
#import "HeaderCell.h"
@interface PeriodTabViewController ()<OKSerCellDelege,OKSerServerDelege>

@end

@implementation PeriodTabViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[WeekCell nib] forCellReuseIdentifier:[WeekCell Identifier]];
    [self.tableView registerNib:[TitleCell nib] forCellReuseIdentifier:[TitleCell Identifier]];
    [self.tableView registerNib:[SetTimeCell nib] forCellReuseIdentifier:[SetTimeCell Identifier]];
    [self.tableView registerNib:[TemperatureCell nib] forCellReuseIdentifier:[TemperatureCell Identifier]];
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    UISwipeGestureRecognizer *swipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedRightButton:)];
    [swipeLeft setDirection:UISwipeGestureRecognizerDirectionLeft];
    [self.view addGestureRecognizer:swipeLeft];
    
    UISwipeGestureRecognizer *swipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(tappedLeftButton:)];
    [swipeRight setDirection:UISwipeGestureRecognizerDirectionRight];
    [self.view addGestureRecognizer:swipeRight];
}
- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.tabBarController.navigationItem.title = [OKSerServer getPeriodNameAtRow:[OKSerServer sharedInstance].singleThermostat.chosePeriod];
    
    [OKSerServer sharedInstance].singleThermostat.isShowPeriod = YES;
    [self showSumitButton:NO];
    [self.tableView reloadData];
    [self.tabBarController.navigationItem setLeftBarButtonItem:[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_back"] landscapeImagePhone:nil style:UIBarButtonItemStyleDone target:self action:@selector(onBackButton:)]];
}
- (void) viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [OKSerServer sharedInstance].singleThermostat.isShowPeriod = NO;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)tappedRightButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    [self.tabBarController setSelectedIndex:selectedIndex + 1];
    CATransition *anim= [CATransition animation];
    [anim setType:kCATransitionMoveIn];
    [anim setSubtype:kCATransitionFromRight];
    [anim setDuration:0.25];
    //    [anim setTimingFunction:[CAMediaTimingFunction functionWithName:
    //                             kCAMediaTimingFunctionEaseIn]];
    [self.tabBarController.view.layer addAnimation:anim forKey:@"fadeTransition"];
}

- (IBAction)tappedLeftButton:(id)sender
{
    NSUInteger selectedIndex = [self.tabBarController selectedIndex];
    
    [self.tabBarController setSelectedIndex:selectedIndex - 1];
    CATransition *anim= [CATransition animation];
    [anim setType:kCATransitionMoveIn];
    [anim setSubtype:kCATransitionFromLeft];
    
    [anim setDuration:0.25];
    //    [anim setTimingFunction:[CAMediaTimingFunction functionWithName:
    //                             kCAMediaTimingFunctionEaseIn]];
    [self.tabBarController.view.layer addAnimation:anim forKey:@"fadeTransition"];
}
#pragma mark - <UITableViewDataSource>

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [OKSerServer getSectionFromViewClass:[self class]];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [OKSerServer getSectionFromViewClass:[self class] numberOfRowsInSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    OKSerTableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:[[OKSerServer getClassFromViewClass:[self class] atIndex:indexPath ] Identifier] forIndexPath:indexPath];
    [cell setCellView:[OKSerServer sharedInstance].singleThermostat ];
    if ([cell class] == [WeekCell class]) {
        WeekCell *weekCell= (WeekCell *)cell;
        [weekCell setAllRadioEnable:NO];
    }
    if ([cell class] == [TitleCell class]) {
        [cell setCellInfo:[OKSerServer getInfoFromViewClass:[self class] atIndex:[NSIndexPath indexPathForRow:indexPath.section inSection:[OKSerServer sharedInstance].singleThermostat.chosePeriod]]];
    }
    cell.delegte = self;
    
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}

#pragma mark - <UITableViewDelegate>
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
   return [[OKSerServer getClassFromViewClass:[self class] atIndex:indexPath ] heightCell];
}
#pragma mark - onButtonClicked
- (void)onBackButton:(id)sender{
    if ([OKSerServer sharedInstance].isNeedSubmit) {
        [self showSumitButton:NO];
        [[OKSerServer sharedInstance] showAlertWithBackButtonOnViewConrtoller:self];
        return;
    }
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)refreshData:(NSDictionary*) dict{
    [self showSumitButton:[[OKSerServer sharedInstance] isNeedSumbitForSetPeriodValueByDict:dict]];
}
- (void) showSumitButton:(BOOL)show{
    if (show) {
        if (![self.tabBarController.navigationItem rightBarButtonItem]) {
            [self.tabBarController.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_ok"] landscapeImagePhone:nil style:UIBarButtonItemStyleDone target:self action:@selector(onRightButton:) ] animated:YES];
        }
    }
    else
    {
        [self.tabBarController.navigationItem setRightBarButtonItem:nil];
    }
    
}
-(void)onRightButton:(id)sender{
    [[OKSerServer sharedInstance] saveDataToThermostats];
    [self showSumitButton:NO];
}
@end
