//
//  TableViewController.m
//  cws
//
//  Created by soeasyright on 2015/11/22.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "ThermostatsViewController.h"
#import "ThermostatsCell.h"
#import "Thermostats.h"
#import "LGAlertView.h"
@interface ThermostatsViewController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIBarButtonItem *searchBarItem;
@property (strong, nonatomic) LGAlertView *securityAlertView;
@property (nonatomic,assign) NSInteger nowEditIndexPathRow;
@property (nonatomic,assign) BOOL isSearchAlertShow; //for textfield
@property (nonatomic,assign) BOOL isSearchNow;
@property (nonatomic,copy) NSString *tmpWifiName;
@property (nonatomic,copy) NSString *tmpWifiPasswd;
@end

@implementation ThermostatsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerNib:[ThermostatsCell nib] forCellReuseIdentifier:[ThermostatsCell Identifier]];
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    self.nowEditIndexPathRow = -1;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(needRefreshForDisplayThermostats:)
                                                 name:@"NeedRefreshForDisplayThermostats"
                                               object:nil];

    
}
- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
    [self.navigationItem setLeftBarButtonItem:[[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_back"] landscapeImagePhone:nil style:UIBarButtonItemStyleDone target:self action:@selector(backClicked:)]];
}

- (void)backClicked:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - <UITableViewDataSource>

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [OKSerServer sharedInstance].thermostats.count;;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ThermostatsCell *cell = [tableView dequeueReusableCellWithIdentifier:[ThermostatsCell Identifier] forIndexPath:indexPath];
    [cell setCellView:[[OKSerServer sharedInstance].thermostats objectAtIndex:indexPath.row] ];
    cell.thermostatName.delegate = self;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.nowEditIndexPathRow != -1 ){
        if(indexPath.row != self.nowEditIndexPathRow) {
            [self.view endEditing:YES];
        }
    }
    else{
        OKSerServer *okser = [OKSerServer sharedInstance];
        okser.choseThermostats = indexPath.row;
        okser.singleThermostat = [okser.thermostats objectAtIndex:indexPath.row];        
        [self performSegueWithIdentifier:@"Thermostats2Configure" sender:indexPath];
    }
    
}
#pragma mark - <UITableViewDelegate>
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [ThermostatsCell heightCell];
}

#pragma mark - <UITextFieldDelegate>
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    if (_isSearchAlertShow)
    {
        if (textField.tag < 1)
            [_securityAlertView.textFieldsArray[(textField.tag + 1)] becomeFirstResponder];
        else
        {
            [textField resignFirstResponder];
        }
    }
    else
    {
        [self.view endEditing:YES];
    }
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (!_isSearchAlertShow){
        CGPoint buttonPosition = [textField convertPoint:CGPointZero
                                                  toView:self.tableView];
        NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:buttonPosition];
        self.nowEditIndexPathRow = indexPath.row;
        [self animateForKeyboard:YES moveValue:indexPath];
    }
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
    if (!_isSearchAlertShow && self.nowEditIndexPathRow != -1){
        [self animateForKeyboard:NO moveValue:[NSIndexPath indexPathForRow:self.nowEditIndexPathRow inSection:0]];
        Thermostats *thermostats= [[OKSerServer sharedInstance].thermostats objectAtIndex:self.nowEditIndexPathRow];
        thermostats.displayName =textField.text;
        [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
        self.nowEditIndexPathRow = -1;
    }
}

#pragma UIAction
- (IBAction)searchButtonClicked:(id)sender {
    
    _isSearchAlertShow = YES;
    _securityAlertView = [[LGAlertView alloc] initWithTextFieldsAndTitle:@"Searching New Thermostat"
                                                                               message:@"Enter Wifi name and Wifi password"
                                                                    numberOfTextFields:2
                                                                textFieldsSetupHandler:^(UITextField *textField, NSUInteger index)
                                        {
                                            if (index == 0)
                                            {
                                                textField.placeholder = @"Wifi name";
                                                textField.text = [OKSerNetwork sharedInstance].globalConfig.ssidName;
                                            }
                                            else if (index == 1)
                                            {
                                                textField.placeholder = @"Wifi password";
                                                textField.secureTextEntry = YES;
                                            }
                                            
                                            textField.tag = index;
                                            textField.delegate = self;
                                            textField.enablesReturnKeyAutomatically = YES;
                                            textField.autocapitalizationType = NO;
                                            textField.autocorrectionType = NO;
                                        }
                                                                          buttonTitles:@[@"Search"]
                                                                     cancelButtonTitle:@"Cancel"
                                                                destructiveButtonTitle:nil
                                                                         actionHandler:^(LGAlertView *alertView, NSString *title, NSUInteger index)
                                        {
                                            
                                            _isSearchAlertShow = NO;
                                            UITextField *name=[alertView.textFieldsArray objectAtIndex:0];
                                            UITextField *pass=[alertView.textFieldsArray objectAtIndex:1];
                                            _tmpWifiName = name.text;
                                            _tmpWifiPasswd = pass.text;
                                            [[OKSerNetwork sharedInstance] startActionWithSSID:_tmpWifiName andPassword:_tmpWifiPasswd];                                            
                                        }
                                                                         cancelHandler:^(LGAlertView *alertView) {
                                                                             _isSearchAlertShow = NO;
                                                                         }
                                                                    destructiveHandler:nil];
    [_securityAlertView showAnimated:YES completionHandler:nil];

    
    
}

#pragma util
- (void)animateForKeyboard:(BOOL)show moveValue:(NSIndexPath *)indexPath{
    ThermostatsCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    [cell.selectBox setHidden:!show];
    [self.tableView setScrollEnabled:!show];
    [self.searchBarItem setEnabled:!show];

}

#pragma NSNotificationCenter
-(void)needRefreshForDisplayThermostats:(id)sender
{
    [self.tableView reloadData];
}

@end
