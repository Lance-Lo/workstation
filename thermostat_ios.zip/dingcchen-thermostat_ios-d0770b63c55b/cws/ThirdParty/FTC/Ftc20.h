//
//  Copyright (c) 2014 Texas Instruments. All rights reserved.
//

#import "FtcEncode.h"

@interface Ftc20 : FtcEncode

@end
