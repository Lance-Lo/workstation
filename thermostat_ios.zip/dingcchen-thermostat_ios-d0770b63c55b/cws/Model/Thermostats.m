//
//  Thermostats.m
//  cws
//
//  Created by soeasyright on 2015/11/30.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "Thermostats.h"
#import "Location.h"

@implementation Thermostats

// Insert code here to add functionality to your managed object subclass
@synthesize nDegree;
@synthesize nHumidity;
@synthesize nSystem;
@synthesize nFan;
@synthesize nOperation;
@synthesize nWeekType;
@synthesize nWeekStatus;
@synthesize nHoldMin;
@synthesize nTemporaryCold;
@synthesize nTemporaryHeat;
@synthesize nPermanentCold;
@synthesize nPermanentHeat;
@synthesize nSc1;
@synthesize nSc2;
@synthesize isReadStatus;
@synthesize isReadConfigure;
@synthesize sSc1;
@synthesize sSc2;
@synthesize show;
@synthesize backupThermostats;
@synthesize chosePeriod;
@synthesize isShowPeriod;
- (void) setSchedule:(NSString *)schedule forIndex:(NSInteger)index
{
    NSArray *sc = [schedule componentsSeparatedByString:@" "];
    NSDictionary *scdict = @{@"wakePeriod":     @{@"nHeat":sc[0],@"nCold":sc[1],@"nHour":sc[2],@"nMin":sc[3]},
                             @"leavePeriod":    @{@"nHeat":sc[4],@"nCold":sc[5],@"nHour":sc[6],@"nMin":sc[7]},
                             @"returnPeriod":   @{@"nHeat":sc[8],@"nCold":sc[9],@"nHour":sc[10],@"nMin":sc[11]},
                             @"sleepPeriod":    @{@"nHeat":sc[12],@"nCold":sc[13],@"nHour":sc[14],@"nMin":sc[15]},
                             };
    ScheduleModel *scModel = [[ScheduleModel alloc] init];
    [scModel mts_setValuesForKeysWithDictionary:scdict];
    
    if (index == 0) {
        self.nSc1 = scModel;
        self.sSc1 = schedule;
    }
    else if (index == 1) {
        self.nSc2 = scModel;
        self.sSc2 = schedule;
    }
//    NSLog(@"%@",schedule);
}

- (NSDictionary *) createBackup
{
    return @{
             @"nSystem":@(self.nSystem),
             @"nFan":@(self.nFan),
             @"nOperation":@(self.nOperation),
             @"nWeekType":@(self.nWeekType),
             @"nHoldMin":@(self.nHoldMin),
             @"nTemporaryHeat":@(self.nTemporaryHeat),
             @"nTemporaryCold":@(self.nTemporaryCold),
             @"nPermanentHeat":@(self.nPermanentHeat),
             @"nPermanentCold":@(self.nPermanentCold),
             @"sSc1":self.sSc1,
             @"sSc2":self.sSc2
             };
}

- (void) cancelChange
{
    
//    NSLog(@"%@",self.backupThermostats);
    self.nSystem = [self.backupThermostats[@"nSystem"] integerValue];
    self.nFan = [self.backupThermostats[@"nFan"] integerValue];
    self.nOperation = [self.backupThermostats[@"nOperation"] integerValue];
    self.nWeekType = [self.backupThermostats[@"nWeekType"] integerValue];
    self.nHoldMin = [self.backupThermostats[@"nHoldMin"] integerValue];
    
    self.nTemporaryHeat = [self.backupThermostats[@"nTemporaryHeat"] integerValue];
    self.nTemporaryCold = [self.backupThermostats[@"nTemporaryCold"] integerValue];
    self.nPermanentHeat = [self.backupThermostats[@"nPermanentHeat"] integerValue];
    self.nPermanentCold = [self.backupThermostats[@"nPermanentCold"] integerValue];
    
    [self setSchedule:self.backupThermostats[@"sSc1"] forIndex:0];
    [self setSchedule:self.backupThermostats[@"sSc2"] forIndex:1];

}

+ (NSString *)tableForSystem:(CWSSystemType) type
{
    static NSArray *table = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        table = @[@"Off",@"Cool",@"Heat",@"Auto"];
        
    });
    return [table objectAtIndex:type];
}

+ (NSString *)tableForFan:(CWSFanType) type
{
    static NSArray *table = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        table = @[@"Auto",@"On",@"Circulate"];
        
    });
    return [table objectAtIndex:type];
}

- (BOOL) isSameThermostats
{
    
    NSLog(@"%@",self.backupThermostats);
    BOOL isSame = YES;
    if (self.nSystem != [self.backupThermostats[@"nSystem"] integerValue] ||
        self.nFan != [self.backupThermostats[@"nFan"] integerValue]||
        self.nOperation != [self.backupThermostats[@"nOperation"] integerValue] ||
        self.nWeekType != [self.backupThermostats[@"nWeekType"] integerValue] ||
        self.nHoldMin != [self.backupThermostats[@"nHoldMin"] integerValue] ||
        self.nPermanentCold != [self.backupThermostats[@"nPermanentCold"] integerValue] ||
        self.nPermanentHeat != [self.backupThermostats[@"nPermanentHeat"] integerValue] ||
        self.nTemporaryCold != [self.backupThermostats[@"nTemporaryCold"] integerValue] ||
        self.nTemporaryHeat != [self.backupThermostats[@"nTemporaryHeat"] integerValue]
        )
    {
        isSame = NO;
    }
    
    else{
         [self refreshScheduleString];
        switch (self.nWeekType) {
            case CWSProgramOptionsType_5_2:
            case CWSProgramOptionsType_6_1:
            {

                if (![self.sSc1 isEqualToString:self.backupThermostats[@"sSc1"]] || ![self.sSc2 isEqualToString:self.backupThermostats[@"sSc2"]] ) {
                    isSame =NO;
                }
            }
                break;
            case CWSProgramOptionsType_7:
            {
                isSame = [self.sSc1 isEqualToString:self.backupThermostats[@"sSc1"]];
            }
                
                break;
        }
    }
    
//    NSLog(isSame ? @"no need ;": @"need sumbit");
    return isSame;
}
- (void) refreshScheduleString
{
    self.sSc1 = [NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d ",
                 self.nSc1.wakePeriod.nHeat,self.nSc1.wakePeriod.nCold,self.nSc1.wakePeriod.nHour,self.nSc1.wakePeriod.nMin,
                 self.nSc1.leavePeriod.nHeat,self.nSc1.leavePeriod.nCold,self.nSc1.leavePeriod.nHour,self.nSc1.leavePeriod.nMin,
                 self.nSc1.returnPeriod.nHeat,self.nSc1.returnPeriod.nCold,self.nSc1.returnPeriod.nHour,self.nSc1.returnPeriod.nMin,
                 self.nSc1.sleepPeriod.nHeat,self.nSc1.sleepPeriod.nCold,self.nSc1.sleepPeriod.nHour,self.nSc1.sleepPeriod.nMin
                 ];
    self.sSc2 = [NSString stringWithFormat:@"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d %d ",
                 self.nSc2.wakePeriod.nHeat,self.nSc2.wakePeriod.nCold,self.nSc2.wakePeriod.nHour,self.nSc2.wakePeriod.nMin,
                 self.nSc2.leavePeriod.nHeat,self.nSc2.leavePeriod.nCold,self.nSc2.leavePeriod.nHour,self.nSc2.leavePeriod.nMin,
                 self.nSc2.returnPeriod.nHeat,self.nSc2.returnPeriod.nCold,self.nSc2.returnPeriod.nHour,self.nSc2.returnPeriod.nMin,
                 self.nSc2.sleepPeriod.nHeat,self.nSc2.sleepPeriod.nCold,self.nSc2.sleepPeriod.nHour,self.nSc2.sleepPeriod.nMin
                 ];
//    NSLog(@"sSc1 %@",self.sSc1);
//    NSLog(@"sSc2 %@",self.sSc2);

}
@end
