//
//  PeriodStatusModel.m
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "PeriodStatusModel.h"
#import <Motis/Motis.h>
@implementation PeriodStatusModel
+ (NSDictionary *)mts_mapping {
    
    return @{@"nHeat": mts_key(nHeat),
             @"nCold": mts_key(nCold),
             @"nHour": mts_key(nHour),
             @"nMin": mts_key(nMin)
             };
}

@end
