//
//  ThermostatsModel.m
//  cws
//
//  Created by soeasyright on 2015/11/25.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "ThermostatsModel.h"
#import <Motis/Motis.h>
@implementation ThermostatsModel

+ (NSDictionary *)mts_mapping {
    
    return @{
            @"nDegree": mts_key(nDegree),
            @"nHumidity": mts_key(nHumidity),
            @"nSystem": mts_key(nSystem),
            @"nFan": mts_key(nFan),
            @"nOperation": mts_key(nOperation),
            @"nWeekType": mts_key(nWeekType),
            @"nWeekStatus" : mts_key(nWeekStatus),
            @"nHoldMin": mts_key(nHoldMin),
            @"nHeat": mts_key(nHeat),
            @"nCold": mts_key(nCold),
            @"nSc1": mts_key(nSc1),
            @"nSc2": mts_key(nSc2),
             };
}


+ (NSString *)tableForSystem:(CWSSystemType) type
{
    static NSArray *table = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        table = @[@"Off",@"Cool",@"Heat",@"Auto"];
        
    });
    return [table objectAtIndex:type];
}

+ (NSString *)tableForFan:(CWSFanType) type
{
    static NSArray *table = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        table = @[@"Auto",@"On",@"Circulate"];
        
    });
    return [table objectAtIndex:type];
}

- (BOOL) isSameThermostats:(ThermostatsModel *)model
{

    BOOL isSame = YES;
    if (self.nSystem != model.nSystem ||
        self.nFan != model.nFan ||
        self.nOperation != model.nOperation ||
        self.nWeekType != model.nWeekType ||
        self.nHoldMin != model.nHoldMin ||
        self.nHeat != model.nHeat ||
        self.nCold != model.nCold
        ) {
        isSame =NO;
    }
//    else{
//        switch (_nWeekType) {
//            case CWSProgramOptionsType_5_2:
//            case CWSProgramOptionsType_6_1:
//            {
//                if (![self.nSc1 isSameSchedule:model.nSc1] || ![self.nSc2 isSameSchedule:model.nSc2]) {
//                    isSame =NO;
//                }
//            }
//                break;
//            case CWSProgramOptionsType_7:
//            {
//                isSame = [self.nSc1 isSameSchedule:model.nSc1];
//            }
//                
//                break;
//        }
//    }
    NSLog(isSame ? @"no need sumbit": @"need sumbit");
    return isSame;
}



@end
