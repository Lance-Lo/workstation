//
//  LocationModel.m
//  cws
//
//  Created by soeasyright on 2015/11/25.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "LocationModel.h"
#import <Motis/Motis.h>
#import "ThermostatsModel.h"
@implementation LocationModel
+ (NSDictionary *)mts_mapping {
    return @{@"locationName": mts_key(locationName),
             @"showImageNum": mts_key(showImageNum),
             @"thermostats": mts_key(thermostats)
             };
}

// Automatic array validation mapping
+ (NSDictionary*)mts_arrayClassMapping
{
    return @{mts_key(thermostats) : ThermostatsModel.class};
}

// Only accept values from the mapping
+ (BOOL)mts_shouldSetUndefinedKeys
{
    return NO;
}
// This method is called when received "null" in non-object types.
- (void)setNilValueForKey:(NSString *)key
{
    NSLog(@"[%@] Null value received for key: %@. Value should be manually set.",[self.class description], key);
    
//    if ([key isEqualToString:mts_key(likesCount)])
//        _likesCount = -1; // <-- Generic default value
}

@end
