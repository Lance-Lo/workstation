//
//  LocationModel.h
//  cws
//
//  Created by soeasyright on 2015/11/25.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LocationModel : NSObject

@property (nonatomic, copy) NSString *locationName;
@property (nonatomic, assign) NSInteger showImageNum;
@property (nonatomic, strong) NSArray *thermostats;

@end
