//
//  Thermostats+CoreDataProperties.h
//  cws
//
//  Created by soeasyright on 2015/11/30.
//  Copyright © 2015年 okser. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Thermostats.h"

NS_ASSUME_NONNULL_BEGIN

@interface Thermostats (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *displayName;
@property (nullable, nonatomic, retain) NSString *wifiPassword;
@property (nullable, nonatomic, retain) NSString *macAdress;
@property (nullable, nonatomic, retain) NSString *ip;
@property (nullable, nonatomic, retain) NSString *wifiName;
@property (nullable, nonatomic, retain) Location *location;

@end

NS_ASSUME_NONNULL_END
