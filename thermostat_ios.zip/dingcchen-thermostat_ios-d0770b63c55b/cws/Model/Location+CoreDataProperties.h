//
//  Location+CoreDataProperties.h
//  cws
//
//  Created by soeasyright on 2015/11/30.
//  Copyright © 2015年 okser. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Location.h"

NS_ASSUME_NONNULL_BEGIN

@interface Location (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *displayName;
@property (nullable, nonatomic, retain) NSNumber *imageTag;
@property (nullable, nonatomic, retain) NSNumber *index;
@property (nullable, nonatomic, retain) NSSet<Thermostats *> *thermostats;

@end

@interface Location (CoreDataGeneratedAccessors)

- (void)addThermostatsObject:(Thermostats *)value;
- (void)removeThermostatsObject:(Thermostats *)value;
- (void)addThermostats:(NSSet<Thermostats *> *)values;
- (void)removeThermostats:(NSSet<Thermostats *> *)values;

@end

NS_ASSUME_NONNULL_END
