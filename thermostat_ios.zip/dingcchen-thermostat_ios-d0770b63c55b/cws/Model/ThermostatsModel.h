//
//  ThermostatsModel.h
//  cws
//
//  Created by soeasyright on 2015/11/25.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ScheduleModel.h"
#import "MTSMotisObject.h"
@interface ThermostatsModel : MTSMotisObject

@property (nonatomic, copy) NSString *nDegree;  //現在溫度
@property (nonatomic, copy) NSString *nHumidity;//現在濕度
@property (nonatomic, assign) CWSSystemType nSystem;//系統設定
@property (nonatomic, assign) CWSFanType nFan;//風扇設定
@property (nonatomic, assign) CWSOperationType nOperation;//操作設定
@property (nonatomic, assign) CWSProgramOptionsType nWeekType;//星期設定
@property (nonatomic, assign) CWSWeekCellStatus nWeekStatus;
@property (nonatomic, assign) NSInteger nHoldMin;//暫時剩餘時間
@property (nonatomic, assign) NSInteger nHeat;//暫時溫度高
@property (nonatomic, assign) NSInteger nCold;//暫時溫度低
@property (nonatomic, copy) ScheduleModel *nSc1;//排程1
@property (nonatomic, copy) ScheduleModel *nSc2;//排程2

+ (NSString *)tableForSystem:(CWSSystemType) type;
+ (NSString *)tableForFan:(CWSFanType) type;
- (BOOL) isSameThermostats:(ThermostatsModel *)model;
//@property (nonatomic, assign) NSInteger currentWeekType;
//           溫高 溫低 小時 分
//__SL_P_SC1=44 90 10 0 45 48 20 0 53 54 30 0 58 76 40 0
//__SL_P_SCH=SCH


//__SL_P_SST:1
//__SL_P_TEC:TEC

@end
