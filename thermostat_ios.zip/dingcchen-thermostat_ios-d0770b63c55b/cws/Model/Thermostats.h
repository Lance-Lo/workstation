//
//  Thermostats.h
//  cws
//
//  Created by soeasyright on 2015/11/30.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "ScheduleModel.h"
@class Location;

NS_ASSUME_NONNULL_BEGIN

@interface Thermostats : NSManagedObject

@property (nonatomic, assign) NSInteger show;
@property (nonatomic, copy) NSString *nDegree;
@property (nonatomic, copy) NSString *nHumidity;
@property (nonatomic, assign) CWSSystemType nSystem;
@property (nonatomic, assign) CWSFanType nFan;
@property (nonatomic, assign) CWSOperationType nOperation;
@property (nonatomic, assign) CWSProgramOptionsType nWeekType;//星期設定
@property (nonatomic, assign) CWSWeekCellStatus nWeekStatus;
@property (nonatomic, assign) NSInteger nHoldMin;
@property (nonatomic, assign) NSInteger nTemporaryCold;
@property (nonatomic, assign) NSInteger nTemporaryHeat;
@property (nonatomic, assign) NSInteger nPermanentCold;
@property (nonatomic, assign) NSInteger nPermanentHeat;
@property (nonatomic, copy) ScheduleModel *nSc1;
@property (nonatomic, copy) ScheduleModel *nSc2;
@property (nonatomic, copy) NSString *sSc1;
@property (nonatomic, copy) NSString *sSc2;
@property (nonatomic, assign) BOOL isReadConfigure;
@property (nonatomic, assign) BOOL isReadStatus;
@property (nonatomic, strong) NSDictionary *backupThermostats;

@property (nonatomic, assign) NSInteger chosePeriod;
@property (nonatomic, assign) BOOL isShowPeriod;

+ (NSString *)tableForSystem:(CWSSystemType) type;
+ (NSString *)tableForFan:(CWSFanType) type;
- (void) setSchedule:(NSString *)schedule forIndex:(NSInteger)index;
- (BOOL) isSameThermostats;
- (void) refreshScheduleString;
- (void) cancelChange;
- (NSDictionary *) createBackup;
@end

NS_ASSUME_NONNULL_END

#import "Thermostats+CoreDataProperties.h"
