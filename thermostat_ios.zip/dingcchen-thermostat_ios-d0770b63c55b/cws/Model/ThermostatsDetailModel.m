//
//  ThermostatsDetailModel.m
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "ThermostatsDetailModel.h"
#import <Motis/Motis.h>
@implementation ThermostatsDetailModel
+ (NSDictionary *)mts_mapping {
    
    return @{@"nDegree": mts_key(nDegree),
             @"nHumidity": mts_key(nHumidity),
             @"nSystem": mts_key(nSystem),
             @"nFan": mts_key(nFan),
             @"nOperation": mts_key(nOperation),
             @"nWeekType": mts_key(nWeekType),
             @"nHoldMin": mts_key(nHoldMin),
             @"nHoldHeat": mts_key(nHoldHeat),
             @"nHoldCold": mts_key(nHoldCold),
             @"nSc1": mts_key(nSc1),
             @"nSc2": mts_key(nSc2),
             };
}

+ (BOOL)mts_shouldSetUndefinedKeys
{
    return NO;
}
//@property (nonatomic, assign) CWSSystemType nSystem;
//@property (nonatomic, assign) CWSFanType nFan;
//@property (nonatomic, assign) CWSOperationType nOperation;
//@property (nonatomic, assign) CWSProgramOptionsType nWeekType;
//+ (NSDictionary*)mts_valueMappingForKey:(NSString*)key
//{
//    if ([key isEqualToString:mts_key(nSystem)])
//    {
//        return @{@0: @(CWSSystemType_Off),
//                 @01: @(CWSSystemType_Cool),
//                 @"female": @(MJUserGenderFemale),
//                 MTSDefaultValue: @(MJUserGenderUndefined),
//                 };
//    }
//    else if ([key isEqualToString:mts_key(awesomenessLevel)])
//    {
//        return @{@1: @(MJAwesomenessLevelZero),
//                 @2: @(MJAwesomenessLevelOne),
//                 @3: @(MJAwesomenessLevelTwo),
//                 @4: @(MJAwesomenessLevelThree),
//                 MTSDefaultValue: @(MJAwesomenessLevelOne),
//                 };
//    }
//    
//    return nil;
//}
//
//typedef NS_ENUM(NSInteger, CWSSystemType) {
//    CWSSystemType_Off = 0,
//    CWSSystemType_Cool = 1,
//    CWSSystemType_Heat = 2,
//    CWSSystemType_Auto = 3,
//};
////__SL_P_SST=1
////__SL_P_TEC=TEC
//typedef NS_ENUM(NSInteger, CWSFanType) {
//    CWSFanType_Auto = 0,
//    CWSSystemType_On = 1,
//    CWSSystemType_Circulate = 2,
//};
////__SL_P_FAN=1
////__SL_P_TEC=TEC
//
//typedef NS_ENUM(NSInteger, CWSOperationType) {
//    CWSOperationType_Hold = 0,
//    CWSOperationType_Schedule = 1,
//    
//};
//__SL_P_S_O=1
//__SL_P_TEC=TEC


//__SL_P_TTH=45 //hold for cold
//__SL_P_TTL=49 //hold for heat

//typedef NS_ENUM(NSInteger, CWSProgramOptionsType) {
//    CWSProgramOptionsType_5_2 = 0,
//    CWSProgramOptionsType_6_1 = 1,
//    CWSProgramOptionsType_7 = 2,
//    
//};

@end
