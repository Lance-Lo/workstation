//
//  Location.m
//  cws
//
//  Created by soeasyright on 2015/11/30.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "Location.h"
#import "Thermostats.h"

@implementation Location
@synthesize thermostatsNum;
@end
