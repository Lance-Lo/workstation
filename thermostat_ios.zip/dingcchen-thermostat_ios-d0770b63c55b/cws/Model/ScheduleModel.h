//
//  ScheduleModel.h
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PeriodStatusModel.h"
#import "MTSMotisObject.h"
@interface ScheduleModel : MTSMotisObject
@property (nonatomic, copy) PeriodStatusModel *wakePeriod;
@property (nonatomic, copy) PeriodStatusModel *leavePeriod;
@property (nonatomic, copy) PeriodStatusModel *returnPeriod;
@property (nonatomic, copy) PeriodStatusModel *sleepPeriod;

@end
