//
//  ScheduleModel.m
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "ScheduleModel.h"
#import <Motis/Motis.h>
@implementation ScheduleModel
+ (NSDictionary *)mts_mapping {
    
    return @{@"wakePeriod": mts_key(wakePeriod),
             @"leavePeriod": mts_key(leavePeriod),
             @"returnPeriod": mts_key(returnPeriod),
             @"sleepPeriod": mts_key(sleepPeriod)
             };
}

@end
