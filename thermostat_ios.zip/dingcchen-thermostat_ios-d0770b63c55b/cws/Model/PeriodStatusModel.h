//
//  PeriodStatusModel.h
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MTSMotisObject.h"
@interface PeriodStatusModel : MTSMotisObject

@property (nonatomic,assign) NSInteger nHeat;
@property (nonatomic,assign) NSInteger nCold;
@property (nonatomic,assign) NSInteger nHour;
@property (nonatomic,assign) NSInteger nMin;

@end
