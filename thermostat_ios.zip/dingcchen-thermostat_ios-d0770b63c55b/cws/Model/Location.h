//
//  Location.h
//  cws
//
//  Created by soeasyright on 2015/11/30.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Thermostats;

NS_ASSUME_NONNULL_BEGIN

@interface Location : NSManagedObject
@property (nonatomic,assign) NSInteger thermostatsNum;
@end

NS_ASSUME_NONNULL_END

#import "Location+CoreDataProperties.h"
