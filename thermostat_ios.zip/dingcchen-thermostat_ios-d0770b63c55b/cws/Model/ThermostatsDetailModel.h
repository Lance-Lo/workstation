//
//  ThermostatsDetailModel.h
//  cws
//
//  Created by soeasyright on 2015/11/26.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <Foundation/Foundation.h>
@class ScheduleModel;

typedef NS_ENUM(NSInteger, CWSSystemType) {
    CWSSystemType_Off = 0,
    CWSSystemType_Cool = 1,
    CWSSystemType_Heat = 2,
    CWSSystemType_Auto = 3,
};
//__SL_P_SST=1
//__SL_P_TEC=TEC
typedef NS_ENUM(NSInteger, CWSFanType) {
    CWSFanType_Auto = 0,
    CWSSystemType_On = 1,
    CWSSystemType_Circulate = 2,
};
//__SL_P_FAN=1
//__SL_P_TEC=TEC

typedef NS_ENUM(NSInteger, CWSOperationType) {
    CWSOperationType_Hold = 0,
    CWSOperationType_Schedule = 1,
    
};
//__SL_P_S_O=1
//__SL_P_TEC=TEC


//__SL_P_TTH=45 //hold for cold
//__SL_P_TTL=49 //hold for heat

typedef NS_ENUM(NSInteger, CWSProgramOptionsType) {
    CWSProgramOptionsType_5_2 = 0,
    CWSProgramOptionsType_6_1 = 1,
    CWSProgramOptionsType_7 = 2,
    
};


@interface ThermostatsDetailModel : NSObject

@property (nonatomic, assign) NSInteger nDegree;
@property (nonatomic, assign) NSInteger nHumidity;
@property (nonatomic, assign) CWSSystemType nSystem;
@property (nonatomic, assign) CWSFanType nFan;
@property (nonatomic, assign) CWSOperationType nOperation;
@property (nonatomic, assign) CWSProgramOptionsType nWeekType;
@property (nonatomic, assign) NSInteger nHoldMin;
@property (nonatomic, assign) NSInteger nHoldHeat;
@property (nonatomic, assign) NSInteger nHoldCold;
@property (nonatomic, strong) ScheduleModel *nSc1;
@property (nonatomic, strong) ScheduleModel *nSc2;


//@property (nonatomic, assign) NSInteger currentWeekType;
//           溫高 溫低 小時 分
//__SL_P_SC1=44 90 10 0 45 48 20 0 53 54 30 0 58 76 40 0
//__SL_P_SCH=SCH


//__SL_P_SST:1
//__SL_P_TEC:TEC
@end
