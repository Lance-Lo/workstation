//
//  OKSerTableViewCell.m
//  cws
//
//  Created by soeasyright on 2015/11/21.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "OKSerTableViewCell.h"

@implementation OKSerTableViewCell
+ (NSString *)Identifier{
    return NSStringFromClass([self class]);
}

+ (UINib *)nib{
   return [UINib nibWithNibName:NSStringFromClass([self class]) bundle:[NSBundle bundleForClass:[self class]]];
}

- (void) setCellView:(NSObject*) model{
}

- (void) setCellView:(NSObject *) model AtIndexPath:(NSIndexPath *)indexPath{
}

- (void) setCellInfo:(NSString *) info{
}
+ (CGFloat )heightCell{
    return 100.;
}
@end
