//
//  OKSerTableViewCell.h
//  cws
//
//  Created by soeasyright on 2015/11/21.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol OKSerCellDelege<NSObject>
- (void)refreshData:(NSDictionary*) dict;
@end

@interface OKSerTableViewCell : UITableViewCell
+ (UINib *) nib;
+ (NSString *) Identifier;
+ (CGFloat ) heightCell;
- (void) setCellView:(NSObject *) model;
- (void) setCellView:(NSObject *) model AtIndexPath:(NSIndexPath *)indexPath;
- (void) setCellInfo:(NSString *) info;
@property (nonatomic,weak) id<OKSerCellDelege> delegte;
@end
