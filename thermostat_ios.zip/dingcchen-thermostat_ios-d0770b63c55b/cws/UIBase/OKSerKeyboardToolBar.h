//
//  OKSerKeyboardToolBar.h
//  cws
//
//  Created by soeasyright on 2015/11/22.
//  Copyright © 2015年 okser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OKSerKeyboardToolBar : UIToolbar
typedef NS_ENUM(NSInteger, OKSerKeyboardToolBarMode) {
    OKSerKeyboardToolBarOnlyDone,
    OKSerKeyboardToolBarALL
};
@property (nonatomic) UIBarButtonItem *previousButton;
@property (nonatomic) UIBarButtonItem *nextButton;
@property (nonatomic) UIBarButtonItem *cancelButton;
@property (nonatomic) UIBarButtonItem *doneButton;
@end
