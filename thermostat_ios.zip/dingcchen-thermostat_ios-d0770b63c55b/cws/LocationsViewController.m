//
//  ViewController.m
//  cws
//
//  Created by soeasyright on 2015/11/21.
//  Copyright © 2015年 okser. All rights reserved.
//

#import "LocationsViewController.h"
#import "ThermostatsViewController.h"
#import "HeaderCell.h"
#import "Location.h"
#import "JCAlertView.h"
@interface LocationsViewController ()<UITextFieldDelegate, OKSerCellDelege>
@property (nonatomic,assign) NSInteger nowEditIndexPathRow;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *addBarItem;
@property (nonatomic,strong) JCAlertView *alert;

@end

@implementation LocationsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[OKSerServer sharedInstance] loadLocationDataFromDB];

    [self.tableView registerNib:[LocationsCell nib] forCellReuseIdentifier:[LocationsCell Identifier]];
    self.navigationItem.hidesBackButton = YES;
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    self.nowEditIndexPathRow = -1;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(reloadTable:)
                                                 name:@"NeedRefreshForThermostatsNum"
                                               object:nil];
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[OKSerServer sharedInstance] loadAllData];
    [self.tableView reloadData];
    
}
- (void) reloadTable:(id)sender{
    [self.tableView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma mark - <UITableViewDataSource>

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [OKSerServer sharedInstance].location.count;
}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        OKSerServer *okser=[OKSerServer sharedInstance];
        Location *location = [okser.location objectAtIndex:indexPath.row];
        [location MR_deleteEntity];
        [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
        [[OKSerServer sharedInstance] loadLocationDataFromDB];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationRight];
    }
}

 - (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
     LocationsCell *cell = [tableView dequeueReusableCellWithIdentifier:[LocationsCell Identifier] forIndexPath:indexPath];
     [cell setCellView:[[OKSerServer sharedInstance].location objectAtIndex:indexPath.row] AtIndexPath:indexPath];
     cell.nameTextField.delegate = self;
     cell.delegte = self;
     return cell;
 }


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.nowEditIndexPathRow != -1 ) {
        if (indexPath.row != self.nowEditIndexPathRow) {
            [self.view endEditing:YES];
        }
    }
    else{
        [OKSerServer sharedInstance].choseLocation = indexPath.row;
        [self performSegueWithIdentifier:@"Location2Thermostats" sender:nil];
    }

    
}
- (void)refreshData:(NSDictionary*) dict{
    if (self.nowEditIndexPathRow != -1) {
        return;
    }

    BOOL isIconClicked = [dict[@"onIconButton"] boolValue];
    if (isIconClicked) {
        UIView *customView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 150, 150)];
        customView.backgroundColor = [UIColor colorWithRed:234./255. green:234./255. blue:234./255. alpha:1.0];
        UIButton *btn = nil;
        btn = [[UIButton alloc] initWithFrame:CGRectMake(12, 12, 50, 50)];
        [btn setImage:[UIImage imageNamed:@"Icon_house"] forState:UIControlStateNormal];
        btn.tag = 0;
        [customView addSubview:btn];
        [btn addTarget:self action:@selector(btnClick1:) forControlEvents:UIControlEventTouchUpInside];
        btn = [[UIButton alloc] initWithFrame:CGRectMake(12, 87, 50, 50)];
        [btn setImage:[UIImage imageNamed:@"Icon_house"] forState:UIControlStateNormal];
        btn.tag = 1;
        [customView addSubview:btn];
        [btn addTarget:self action:@selector(btnClick1:) forControlEvents:UIControlEventTouchUpInside];
        btn = [[UIButton alloc] initWithFrame:CGRectMake(87, 12, 50, 50)];
        [btn setImage:[UIImage imageNamed:@"Icon_house"] forState:UIControlStateNormal];
        btn.tag = 2;
        [customView addSubview:btn];
        [btn addTarget:self action:@selector(btnClick1:) forControlEvents:UIControlEventTouchUpInside];
        btn = [[UIButton alloc] initWithFrame:CGRectMake(87, 87, 50, 50)];
        [btn setImage:[UIImage imageNamed:@"Icon_house"] forState:UIControlStateNormal];
        btn.tag = 3;
        [customView addSubview:btn];
        [btn addTarget:self action:@selector(btnClick1:) forControlEvents:UIControlEventTouchUpInside];
        // dismissWhenTouchedBackground:NO
        UIView *line = [[UIView alloc] initWithFrame:CGRectMake(74.5, 0, 1, 150)];
        line.backgroundColor = [UIColor colorWithRed:175./255. green:175./255. blue:175./255. alpha:1.0];
        [customView addSubview:line];
        line = [[UIView alloc] initWithFrame:CGRectMake(0, 74.5, 150, 1)];
        line.backgroundColor = [UIColor colorWithRed:175./255. green:175./255. blue:175./255. alpha:1.0];
        [customView addSubview:line];
        _alert = [[JCAlertView alloc] initWithCustomView:customView dismissWhenTouchedBackground:NO];
        [_alert show];
        self.nowEditIndexPathRow = [dict[@"CellRow"] integerValue];
        [self animateForKeyboard:YES moveValue:[NSIndexPath indexPathForRow:self.nowEditIndexPathRow inSection:0]];
    }
    else{
        [OKSerServer sharedInstance].choseLocation = [dict[@"CellRow"] integerValue];
        [self performSegueWithIdentifier:@"Location2Thermostats" sender:nil];
    }
}

#pragma mark - <UITableViewDelegate>
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [LocationsCell heightCell];
}

#pragma mark - <UITextFieldDelegate>
- (BOOL)textFieldShouldReturn:(UITextField *)theTextField {
    [self.view endEditing:YES];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    CGPoint buttonPosition = [textField convertPoint:CGPointZero
                                              toView:self.tableView];
    NSIndexPath *indexPath = [self.tableView indexPathForRowAtPoint:buttonPosition];
    self.nowEditIndexPathRow = indexPath.row;
    [self animateForKeyboard:YES moveValue:indexPath];
}
-(void)textFieldDidEndEditing:(UITextField *)textField{
    [self animateForKeyboard:NO moveValue:[NSIndexPath indexPathForRow:self.nowEditIndexPathRow inSection:0]];
    Location *location= [[OKSerServer sharedInstance].location objectAtIndex:self.nowEditIndexPathRow];
    location.displayName =textField.text;
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
    self.nowEditIndexPathRow = -1;
    
}
#pragma UIAction
- (IBAction)addButtonClicked:(id)sender {
//            [[OKSerNetwork sharedInstance] startAction];

    Location *locaiotn = [Location MR_createEntity];
    locaiotn.displayName = @"Default";
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger count = [[userDefaults objectForKey:CWSTotalLocationCount] integerValue];
    count += 1;
    [userDefaults setObject:@(count) forKey:CWSTotalLocationCount];
    [userDefaults synchronize];
    locaiotn.index = @(count);
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
    
    [[OKSerServer sharedInstance] loadLocationDataFromDB];
    [self.tableView beginUpdates];
    [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationFade];
    [self.tableView endUpdates];
    [self.tableView reloadData];
}
-(void) btnClick1:(UIButton *)sender
{
    Location *location= [[OKSerServer sharedInstance].location objectAtIndex:self.nowEditIndexPathRow];
    location.imageTag =@(sender.tag);
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreAndWait];
    [self animateForKeyboard:NO moveValue:[NSIndexPath indexPathForRow:self.nowEditIndexPathRow inSection:0]];
    [_alert dismissWithCompletion:nil];
    self.nowEditIndexPathRow = -1;
}

#pragma util
- (void)animateForKeyboard:(BOOL)show moveValue:(NSIndexPath *)indexPath{
    LocationsCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    [cell.selectBox setHidden:!show];
    [self.tableView setScrollEnabled:!show];
    self.addBarItem.enabled=!show;
}

@end
